﻿Imports MySql.Data.MySqlClient

Public Class DashboardSAsuboffer
    Dim count As Integer = 0


    Private Sub RefreshData()
        Try

            count = LoadToDGV("SELECT * FROM `availablesubscription` ORDER BY id DESC;", dvgclient)

            lblcount.Text = "Total Records: " & count
            'if i dont want to display ID


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `availablesubscription`;")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `availablesubscription`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub






    Private Sub DashboardSAsuboffer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateConnectionString()
        Me.WindowState = FormWindowState.Maximized
        Try
            SetupAutoRefresh()
            RefreshData()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtsname_TextChanged(sender As Object, e As EventArgs) Handles txtsname.TextChanged

    End Sub

    Private Sub txtprice_TextChanged(sender As Object, e As EventArgs) Handles txtprice.TextChanged

    End Sub

    Private Sub txtspeed_TextChanged(sender As Object, e As EventArgs) Handles txtspeed.TextChanged

    End Sub

    Private Sub textfee_TextChanged(sender As Object, e As EventArgs) Handles textfee.TextChanged

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            ' Validate inputs
            If txtsname.Text.Trim = Nothing Then
                MsgBox("Enter Subscription Name.")
                txtsname.Focus()
                Exit Sub
            End If
            If txtprice.Text.Trim = Nothing Then
                MsgBox("Enter Price of Subscription.")
                txtprice.Focus()
                Exit Sub
            End If
            If txtspeed.Text.Trim = Nothing Then
                MsgBox("Enter Speed.")
                txtspeed.Focus()
                Exit Sub
            End If
            If textfee.Text.Trim = Nothing Then
                MsgBox("Enter Setup Fee.")
                textfee.Focus()
                Exit Sub
            End If

            ' Confirm save
            If MsgBox("Are you sure you want to save this subscription with the name: " & txtsname.Text.Trim & "?", MsgBoxStyle.YesNo, "Save") = MsgBoxResult.Yes Then
                ' Execute the query
                readQuery(String.Format("INSERT INTO `availablesubscription` (`SubscriptionName`, `PriceofSubscription`, `Speed`, `Setupfee`) " &
                                        "VALUES ('{0}', {1}, '{2}', '{3}')",
                                        txtsname.Text.Trim, txtprice.Text.Trim, txtspeed.Text.Trim, textfee.Text.Trim))

                MsgBox("Subscription Saved!")
                RefreshData()
                Log("Saved new subscription" & "by: " & CurrentLoggedUser.username, "btnadd_Click")


            End If

            Try
                DashboardSA.WindowState = FormWindowState.Maximized
                Dim dashboard As DashboardC = CType(Application.OpenForms("DashboardC"), DashboardC)
                If dashboard IsNot Nothing Then
                    dashboard.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard1 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                If dashboard1 IsNot Nothing Then
                    dashboard1.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard2 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                If dashboard2 IsNot Nothing Then
                    dashboard2.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard3 As CrudSAsubscription = CType(Application.OpenForms(" CrudSAsubscription"), CrudSAsubscription)
                If dashboard3 IsNot Nothing Then
                    dashboard3.RefreshDashboard() ' Call the refresh method
                End If

            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dvgclient_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgclient.CellContentDoubleClick
        Try
            ' Ensure the clicked row index is valid
            If e.RowIndex >= 0 Then
                ' Map the values from DataGridView to the corresponding fields based on the table structure
                txtsname.Tag = dvgclient.Rows(e.RowIndex).Cells(0).Value ' ID (Hidden or not displayed)
                txtsname.Text = dvgclient.Rows(e.RowIndex).Cells(1).Value.ToString() ' Subscription Name
                txtprice.Text = dvgclient.Rows(e.RowIndex).Cells(2).Value.ToString() ' Price of Subscription
                txtspeed.Text = dvgclient.Rows(e.RowIndex).Cells(3).Value.ToString() ' Speed
                textfee.Text = dvgclient.Rows(e.RowIndex).Cells(4).Value.ToString() ' Setup Fee

                ' Optional: Handle the DateRegisteredSubscription field if needed
                ' lblDateRegistered.Text = dvgclient.Rows(e.RowIndex).Cells(5).Value.ToString() ' Date Registered Subscription
            End If
        Catch ex As Exception
            MsgBox("An error occurred while selecting a record: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            ' Validate inputs for required fields
            If txtsname.Text.Trim = Nothing Then
                MsgBox("Enter Subscription Name.")
                txtsname.Focus()
                Exit Sub
            End If
            If txtprice.Text.Trim = Nothing Then
                MsgBox("Enter Price of Subscription.")
                txtprice.Focus()
                Exit Sub
            End If
            If txtspeed.Text.Trim = Nothing Then
                MsgBox("Enter Speed.")
                txtspeed.Focus()
                Exit Sub
            End If
            If textfee.Text.Trim = Nothing Then
                MsgBox("Enter Setup Fee.")
                textfee.Focus()
                Exit Sub
            End If

            ' Confirmation prompt
            If MsgBox("Are you sure you want to update this record with the name: " & txtsname.Text.Trim & "?", MsgBoxStyle.YesNo, "Update") = MsgBoxResult.Yes Then
                ' Update query based on the table structure
                readQuery(String.Format("UPDATE `availablesubscription` SET `SubscriptionName`='{0}', `PriceofSubscription`={1}, `Speed`='{2}', `Setupfee`='{3}' WHERE `Id`={4}",
                            txtsname.Text, txtprice.Text, txtspeed.Text, textfee.Text, txtsname.Tag))

                ' Notify success and refresh data
                MsgBox("Subscription updated successfully.")
                Log("Updated the subscription" & "by: " & CurrentLoggedUser.username, "btnupdate_Click")


                RefreshData()
            End If
            Try
                DashboardSA.WindowState = FormWindowState.Maximized
                Dim dashboard As DashboardC = CType(Application.OpenForms("DashboardC"), DashboardC)
                If dashboard IsNot Nothing Then
                    dashboard.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard1 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                If dashboard1 IsNot Nothing Then
                    dashboard1.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard2 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                If dashboard2 IsNot Nothing Then
                    dashboard2.RefreshDashboard() ' Call the refresh method
                End If
                Dim dashboard3 As CrudSAsubscription = CType(Application.OpenForms(" CrudSAsubscription"), CrudSAsubscription)
                If dashboard3 IsNot Nothing Then
                    dashboard3.RefreshDashboard() ' Call the refresh method
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try

        Catch ex As Exception
            ' Handle errors
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        Try
            ' Clear all input fields related to the availablesubscription table
            txtsname.Clear() ' Clear Subscription Name
            txtprice.Clear()
            txtspeed.Clear()
            textfee.Clear()
        Catch ex As Exception
            ' Handle any errors
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnd_Click(sender As Object, e As EventArgs) Handles btnd.Click
        DashboardSA.Show()
        Me.Hide()

    End Sub

    Private Sub btng_Click(sender As Object, e As EventArgs) Handles btng.Click
        GraphSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        ReportSA.Show()

    End Sub

    Private Sub btnlogs_Click(sender As Object, e As EventArgs) Handles btnlogs.Click
        Logs.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `availablesubscription` WHERE CONCAT(SubscriptionName, ' ', Speed) LIKE '%" & txtname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            ' Ensure that a valid subscription ID (tag) is set before attempting deletion
            If txtsname.Tag IsNot Nothing AndAlso txtsname.Tag.ToString() <> "" Then
                ' Confirmation before deletion
                If MsgBox("Are you sure you want to delete the record with the subscription name: " & txtsname.Text & "?", MsgBoxStyle.YesNo, "DELETE") = MsgBoxResult.Yes Then
                    ' Perform the delete query using the ID stored in txtsname.Tag
                    readQuery("DELETE FROM `availablesubscription` WHERE `Id`=" & txtsname.Tag)

                    ' Notify the user and refresh the data
                    MsgBox("Record deleted successfully.")
                    RefreshData()
                    Log("Delete an subscription", "btnadd_Click")
                    DashboardSA.WindowState = FormWindowState.Maximized
                    Dim dashboard As DashboardC = CType(Application.OpenForms("DashboardC"), DashboardC)
                    If dashboard IsNot Nothing Then
                        dashboard.RefreshDashboard() ' Call the refresh method
                    End If
                    Dim dashboard1 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                    If dashboard1 IsNot Nothing Then
                        dashboard1.RefreshDashboard() ' Call the refresh method
                    End If
                    Dim dashboard2 As CrudSAsub = CType(Application.OpenForms(" CrudSAsub"), CrudSAsub)
                    If dashboard2 IsNot Nothing Then
                        dashboard2.RefreshDashboard() ' Call the refresh method
                    End If
                    Dim dashboard3 As CrudSAsubscription = CType(Application.OpenForms(" CrudSAsubscription"), CrudSAsubscription)
                    If dashboard3 IsNot Nothing Then
                        dashboard3.RefreshDashboard() ' Call the refresh method
                    End If
                End If
            Else
                ' Handle the case where no valid subscription ID is found
                MsgBox("No subscription selected to delete.", MsgBoxStyle.Critical)
                Log("Delete an subscription" & "by: " & CurrentLoggedUser.username, "btndelete_Click")
            End If
        Catch ex As Exception
            ' Handle any errors
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        FeedbackSA.Show()

        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RefreshData()
        SetupAutoRefresh()

    End Sub
End Class