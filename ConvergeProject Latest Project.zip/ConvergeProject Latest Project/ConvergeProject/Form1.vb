﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtuname.Clear()
        txtpass.Clear()
        Try
            Me.WindowState = FormWindowState.Maximized
            txtpass.UseSystemPasswordChar = True
            txtuname.Clear()
            txtpass.Clear()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try



    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click

        UpdateConnectionString()
        Dim username As String = txtuname.Text
        Dim password As String = txtpass.Text

        Try
            openConn(db_name)

            ' Check if the admin table is empty
            Dim checkAdminTableQuery As String = "SELECT COUNT(*) FROM `admin`"
            Using checkCmd As New MySqlCommand(checkAdminTableQuery, conn)
                Dim adminCount As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())
                If adminCount = 0 Then
                    ' If admin table is empty, open the CreateAccount form
                    MessageBox.Show("No admin account exists. Please create an admin account.", "No Admin Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    CreateAccount.Show()
                    Me.Hide()
                    Return
                End If
            End Using

            ' Validate inputs (check if username or password is empty)
            If String.IsNullOrWhiteSpace(username) Then
                MessageBox.Show("Please enter your username.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtuname.Focus()
                Return
            End If

            If String.IsNullOrWhiteSpace(password) Then
                MessageBox.Show("Please enter your password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtpass.Focus()
                Return
            End If

            ' Define query to check credentials in admin table
            Dim query As String = "SELECT * FROM `admin` WHERE Username = @username"
            Using cmd As New MySqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@username", username)

                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    If reader.HasRows Then
                        If reader.Read() Then
                            Dim encryptedPasswordFromDb As String = reader("Password").ToString()
                            Dim decryptedPassword As String = Decrypt(encryptedPasswordFromDb)

                            If decryptedPassword = password Then
                                Dim position As String = reader("Position").ToString()
                                Dim municipality As String = reader("Municipality").ToString()

                                ' Populate CurrentLoggedUser for admin or super admin
                                CurrentLoggedUser = New LoggedUser With {
                                    .id = Convert.ToInt32(reader("ID")),
                                    .username = reader("Username").ToString(),
                                    .position = If(position.Equals("SuperAdmin", StringComparison.OrdinalIgnoreCase), 1, 2),
                                    .role = position,
                                    .municipality = municipality
                                }

                                If position.Equals("SuperAdmin", StringComparison.OrdinalIgnoreCase) Then
                                    MessageBox.Show("SuperAdmin login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                    DashboardSA.Show()
                                    Me.Hide()
                                ElseIf position.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
                                    MessageBox.Show($"Admin login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                    AdminDashboard.Show()
                                    Me.Hide()
                                Else
                                    MessageBox.Show("Invalid position specified.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End If
                            Else
                                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                txtuname.Focus()
                            End If
                        End If
                    Else
                        reader.Close()

                        ' If no matching rows in admin, check clientinfo table
                        Dim queryClientInfo As String = "SELECT * FROM `clientinfo` WHERE Username = @username"
                        Using clientCmd As New MySqlCommand(queryClientInfo, conn)
                            clientCmd.Parameters.AddWithValue("@username", username)

                            Using clientReader As MySqlDataReader = clientCmd.ExecuteReader()
                                If clientReader.HasRows Then
                                    clientReader.Read()
                                    Dim encryptedPasswordFromDb As String = clientReader("Password").ToString()
                                    Dim decryptedPassword As String = Decrypt(encryptedPasswordFromDb)

                                    If decryptedPassword = password Then
                                        ' Populate CurrentLoggedUser for client
                                        CurrentLoggedUser = New LoggedUser With {
                                            .id = Convert.ToInt32(clientReader("ID")),
                                            .username = clientReader("Username").ToString(),
                                            .position = 3,
                                            .role = "Client",
                                            .municipality = clientReader("Municipality").ToString()
                                        }

                                        MessageBox.Show("Client login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                        DashboardC.Show()
                                        Me.Hide()
                                    Else
                                        MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                        txtuname.Focus()
                                    End If
                                Else
                                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    txtuname.Focus()
                                End If
                            End Using
                        End Using
                    End If
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show($"Database Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show($"General Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub


    Private Sub btncreate_Click(sender As Object, e As EventArgs)
        CreateAccount.Show()
        Me.Hide()
    End Sub

    Private Sub txtpass_TextChanged(sender As Object, e As EventArgs) Handles txtpass.TextChanged

    End Sub

    Private Sub cbshow_CheckedChanged(sender As Object, e As EventArgs) Handles cbshow.CheckedChanged

        txtpass.UseSystemPasswordChar = Not cbshow.Checked
    End Sub

    Private Sub txtuname_TextChanged(sender As Object, e As EventArgs) Handles txtuname.TextChanged

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown

        If e.Control AndAlso e.KeyCode = Keys.F1 Then

            AdminConnection.Show()
        ElseIf e.Control AndAlso e.KeyCode = Keys.F2 Then

            CreateAccount.Show()
        End If
    End Sub
End Class
