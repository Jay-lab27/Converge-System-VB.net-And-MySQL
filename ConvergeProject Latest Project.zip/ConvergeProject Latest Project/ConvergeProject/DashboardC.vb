﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar
Imports MySql.Data.MySqlClient

Public Class DashboardC
    Dim count As Integer = 0
    Dim timer As New Timer()

    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method
    End Sub
    Private Sub RefreshData()
        Try
            LoadToDGV("SELECT * FROM `availablesubscription`;", dvgclient2)


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `availablesubscription`;")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `availablesubscription`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub




    Private Sub DashboardC_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Maximized
        Try
            SetupAutoRefresh()
            RefreshData()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub


    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtuname_TextChanged(sender As Object, e As EventArgs) Handles txtuname.TextChanged

    End Sub

    Private Sub txtname1_TextChanged(sender As Object, e As EventArgs) Handles txtname1.TextChanged

    End Sub

    Private Sub txtfname_TextChanged(sender As Object, e As EventArgs) Handles txtfname.TextChanged

    End Sub

    Private Sub txtmname_TextChanged(sender As Object, e As EventArgs) Handles txtmname.TextChanged

    End Sub

    Private Sub Adate_ValueChanged(sender As Object, e As EventArgs) Handles Adate.ValueChanged

    End Sub

    Private Sub txtmun_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtmun.SelectedIndexChanged

    End Sub

    Private Sub txtreq_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtreq.SelectedIndexChanged

    End Sub

    Private Sub txtreqd_TextChanged(sender As Object, e As EventArgs) Handles txtreqd.TextChanged

    End Sub

    Private Sub btncon_Click(sender As Object, e As EventArgs) Handles btncon.Click
        Try
            ' Validate inputs
            If txtId.Text.Trim = String.Empty Then
                MsgBox("Enter valid UserID.")
                txtId.Focus()
                Exit Sub
            End If

            If txtuname.Text.Trim = String.Empty Then
                MsgBox("Enter Username.")
                txtuname.Focus()
                Exit Sub
            End If

            If txtname1.Text.Trim = String.Empty Then
                MsgBox("Enter Lastname.")
                txtname1.Focus()
                Exit Sub
            End If

            If txtfname.Text.Trim = String.Empty Then
                MsgBox("Enter Firstname.")
                txtfname.Focus()
                Exit Sub
            End If

            If txtmname.Text.Trim = String.Empty Then
                MsgBox("Enter Middlename.")
                txtmname.Focus()
                Exit Sub
            End If

            If txtgmail.Text.Trim = String.Empty Then
                MsgBox("Enter Gmail.")
                txtgmail.Focus()
                Exit Sub
            End If

            If txtnum.Text.Trim = String.Empty Then
                MsgBox("Enter Contact Number.")
                txtnum.Focus()
                Exit Sub
            End If

            If Adate.Text.Trim = String.Empty Then
                MsgBox("Enter Appointment Date.")
                Adate.Focus()
                Exit Sub
            End If

            If cmbamorpm.SelectedIndex = -1 Then
                MsgBox("Select Appointment Period (AM or PM).")
                cmbamorpm.Focus()
                Exit Sub
            End If

            If txtmun.Text.Trim = String.Empty Then
                MsgBox("Enter Municipality.")
                txtmun.Focus()
                Exit Sub
            End If

            If cmbzip.SelectedIndex = -1 Then
                MsgBox("Select Zipcode.")
                cmbzip.Focus()
                Exit Sub
            End If

            If txtreq.Text.Trim = String.Empty Then
                MsgBox("Enter Appointment Request.")
                txtreq.Focus()
                Exit Sub
            End If

            If txtreqd.Text.Trim = String.Empty Then
                MsgBox("Enter Request Detail.")
                txtreqd.Focus()
                Exit Sub
            End If

            ' Check if the UserID exists in the client_info table
            Dim userIdExists As Boolean = False

            Dim query As String = "SELECT COUNT(*) FROM clientinfo WHERE Id = @UserID"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@UserID", txtId.Text.Trim)
                    userIdExists = Convert.ToInt32(cmd.ExecuteScalar()) > 0
                End Using


            If Not userIdExists Then
                MsgBox("You cannot send this appointment because this is not a valid ID.")
                Exit Sub
            End If

            If MsgBox("Are you sure you want to save the appointment for " & txtuname.Text.Trim & "?", MsgBoxStyle.YesNo, "Save Appointment") = MsgBoxResult.Yes Then
                ' Execute the query with correct fields for the 'appointment' table
                readQuery(String.Format("INSERT INTO appointment (UserID, Username, Lastname, Firstname, Middlename, Gmail, ContactNo, AppointmentDate, AppointmentPeriod, Municipality, Zipcode, AppointmentRequest, RequestDetail, DateRegisteredAppointment) 
                                  VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7:yyyy-MM-dd}', '{8}', '{9}', '{10}', '{11}', '{12}', NOW())",
                                      txtId.Text.Trim, txtuname.Text.Trim, txtname1.Text.Trim, txtfname.Text.Trim, txtmname.Text.Trim,
                                      txtgmail.Text.Trim, txtnum.Text.Trim, Adate.Value, cmbamorpm.SelectedItem.ToString(),
                                      txtmun.Text.Trim, cmbzip.SelectedItem.ToString(), txtreq.Text.Trim, txtreqd.Text.Trim))

                ' Refresh Dashboard if needed
                MsgBox("Saved successfully!")

                ' Clear the form fields
                txtId.Clear()
                txtuname.Clear()
                txtname1.Clear()
                txtfname.Clear()
                txtmname.Clear()
                txtgmail.Clear()
                txtnum.Clear()
                Adate.Value = DateTime.Now
                cmbamorpm.SelectedIndex = -1
                txtmun.SelectedIndex = -1
                cmbzip.SelectedIndex = -1
                txtreq.SelectedIndex = -1
                txtreqd.Clear()
            End If

            If Application.OpenForms("DashboardSAAP") IsNot Nothing Then
                Dim dashboard As DashboardSAAP = CType(Application.OpenForms("DashboardSAAP"), DashboardSAAP)
                dashboard.RefreshDashboard()
            End If
        Catch ex As Exception
            ' Display the error message only if something goes wrong
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub cmbzip_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbzip.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DashboardCF.Show()
        Me.Hide()

    End Sub

    Private Sub btnhistory_Click(sender As Object, e As EventArgs) Handles btnhistory.Click
        DashboardCH.Show()
        Me.Hide()

    End Sub

    Private Sub btnappoint_Click(sender As Object, e As EventArgs) Handles btnappoint.Click

    End Sub

    Private Sub txtId_TextChanged(sender As Object, e As EventArgs) Handles txtId.TextChanged

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        RefreshDashboard()
        SetupAutoRefresh()
        RefreshData()
    End Sub
End Class