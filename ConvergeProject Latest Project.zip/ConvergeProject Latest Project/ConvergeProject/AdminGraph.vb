﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting


Public Class AdminGraph

    Dim count As Integer = 0
    Dim timer As New Timer()

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub





    Private Sub dptdatepick_ValueChanged(sender As Object, e As EventArgs) Handles dptdatepick.ValueChanged
        Try
            ' Get the selected month and year from the DateTimePicker
            Dim selectedMonth As Integer = dptdatepick.Value.Month
            Dim selectedYear As Integer = dptdatepick.Value.Year

            ' Query to count total subscriptions for each municipality from clientinfo
            Dim queryTotal As String = "
        SELECT Municipality, COUNT(*) AS TotalSubscriptions
        FROM clientinfo
        GROUP BY Municipality"

            ' Query to count paid subscriptions for each municipality from payment
            Dim queryPaid As String = "
        SELECT Municipality, COUNT(*) AS PaidSubscriptions
        FROM payments
        WHERE MONTH(Dateofpayment) = @SelectedMonth 
        AND YEAR(Dateofpayment) = @SelectedYear 
        AND Payment > 0
        GROUP BY Municipality"

            ' DataTables for results
            Dim dtTotal As New DataTable
            Dim dtPaid As New DataTable

            ' Open connection and fetch data
            openConn(db_name)

            ' Execute the total subscriptions query
            Using cmdTotal As New MySqlCommand(queryTotal, conn)
                Using adapterTotal As New MySqlDataAdapter(cmdTotal)
                    adapterTotal.Fill(dtTotal)
                End Using
            End Using

            ' Execute the paid subscriptions query
            Using cmdPaid As New MySqlCommand(queryPaid, conn)
                cmdPaid.Parameters.AddWithValue("@SelectedMonth", selectedMonth)
                cmdPaid.Parameters.AddWithValue("@SelectedYear", selectedYear)

                Using adapterPaid As New MySqlDataAdapter(cmdPaid)
                    adapterPaid.Fill(dtPaid)
                End Using
            End Using

            ' Merge the data (left join TotalSubscriptions with PaidSubscriptions on Municipality)
            Dim resultTable As New DataTable
            resultTable.Columns.Add("Municipality", GetType(String))
            resultTable.Columns.Add("TotalSubscriptions", GetType(Integer))
            resultTable.Columns.Add("PaidSubscriptions", GetType(Integer))

            ' Create a dictionary for paid subscriptions to avoid multiple lookups
            Dim paidDict As New Dictionary(Of String, Integer)

            For Each paidRow As DataRow In dtPaid.Rows
                Dim municipality As String = paidRow("Municipality").ToString()
                Dim paidSubscriptions As Integer = Convert.ToInt32(paidRow("PaidSubscriptions"))
                paidDict(municipality) = paidSubscriptions
            Next

            ' Add rows to resultTable, using paidDict for paid subscription counts
            For Each totalRow As DataRow In dtTotal.Rows
                Dim municipality As String = totalRow("Municipality").ToString()
                Dim totalSubscriptions As Integer = Convert.ToInt32(totalRow("TotalSubscriptions"))

                ' Get corresponding paid subscriptions, default to 0 if not found
                Dim paidSubscriptions As Integer = If(paidDict.ContainsKey(municipality), paidDict(municipality), 0)

                ' Add the merged row to the result table
                resultTable.Rows.Add(municipality, totalSubscriptions, paidSubscriptions)
            Next

            ' Configure the chart
            dvgclient.Series.Clear()

            ' Add data series for total subscriptions
            Dim totalSeries As New Series("Total Subscriptions")
            totalSeries.ChartType = SeriesChartType.Column
            totalSeries.IsValueShownAsLabel = True

            ' Add data series for paid subscriptions
            Dim paidSeries As New Series("Paid Subscriptions")
            paidSeries.ChartType = SeriesChartType.Column
            paidSeries.IsValueShownAsLabel = True

            ' Populate the series with data
            For Each row As DataRow In resultTable.Rows
                Dim municipality As String = row("Municipality").ToString()
                Dim totalSubscriptions As Integer = Convert.ToInt32(row("TotalSubscriptions"))
                Dim paidSubscriptions As Integer = Convert.ToInt32(row("PaidSubscriptions"))

                totalSeries.Points.AddXY(municipality, totalSubscriptions)
                paidSeries.Points.AddXY(municipality, paidSubscriptions)
            Next

            ' Add series to the chart
            dvgclient.Series.Add(totalSeries)
            dvgclient.Series.Add(paidSeries)

            ' Configure chart area
            Dim chartArea As ChartArea = dvgclient.ChartAreas(0)
            chartArea.AxisX.Title = "Municipality"
            chartArea.AxisY.Title = "Count"
            chartArea.AxisY.IsStartedFromZero = True
            chartArea.RecalculateAxesScale()

        Catch ex As Exception
            MessageBox.Show($"Error loading chart data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub




    Private Sub btna_Click(sender As Object, e As EventArgs) Handles btna.Click
        AdminGraph1.Show()
        Me.Hide()

    End Sub

    Private Sub btnd_Click(sender As Object, e As EventArgs) Handles btnd.Click
        AdminDashboard.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        AdminReport.Show()
        Me.Hide()
    End Sub

    Private Sub btnsubo_Click(sender As Object, e As EventArgs) Handles btnsubo.Click
        Adminsuboffer.Show()
        Me.Hide()

    End Sub


    Private Sub AdminGraph_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Me.WindowState = FormWindowState.Maximized
            SetupAutoRefresh()
            RefreshDashboard()
            Refresh()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub


    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Get counts for each table separately
            Dim paymentsCount As Integer = GetRowCount("SELECT COUNT(*) FROM `payments`")
            Dim clientInfoCount As Integer = GetRowCount("SELECT COUNT(*) FROM `clientinfo`")

            ' Calculate total count (or handle them separately)
            Dim newCount As Integer = paymentsCount + clientInfoCount

            If newCount <> count Then
                count = newCount
                RefreshGraph()
                LoadMunicipalityChart()

            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()

                ' Queries for the row count from each table
                Dim paymentsQuery As String = "SELECT COUNT(*) FROM `payments`;"
                Dim clientInfoQuery As String = "SELECT COUNT(*) FROM `clientinfo`;"

                ' Execute each query and retrieve the row counts
                Dim paymentsCount As Integer
                Dim clientInfoCount As Integer

                ' Execute payments count query
                Using cmd As New MySqlCommand(paymentsQuery, connection)
                    paymentsCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Execute client info count query
                Using cmd As New MySqlCommand(clientInfoQuery, connection)
                    clientInfoCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Calculate total count (or handle them separately)
                Dim newCount As Integer = paymentsCount + clientInfoCount

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    count = newCount
                    RefreshGraph()
                    LoadMunicipalityChart() ' Refresh both payments and client info chart data
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub




    Public Sub RefreshGraph()
        LoadMunicipalityChart()

        Try
            ' Query to count total records in the clientinfo table
            Dim query As String = "SELECT COUNT(*) AS Total FROM clientinfo"

            ' Open the connection and execute the query
            openConn(db_name)
            Using cmd As New MySqlCommand(query, conn)
                Dim result As Object = cmd.ExecuteScalar()
                count = If(IsDBNull(result), 0, Convert.ToInt32(result))
            End Using

            ' Update the label with the total record count
            lbl.Text = "Total Client: " & count.ToString()

        Catch ex As Exception
            MessageBox.Show($"Error retrieving record count: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub


    Public Sub RefreshDashboard()
        RefreshGraph()
    End Sub  ' Load Municipality chart with updated payments and client info data
    Private Sub LoadMunicipalityChart()
        Try
            ' Get the selected month and year from the DateTimePicker
            Dim selectedMonth As Integer = dptdatepick.Value.Month
            Dim selectedYear As Integer = dptdatepick.Value.Year

            ' Query to count total subscriptions for each municipality from clientinfo
            Dim queryTotal As String = "
            SELECT Municipality, COUNT(*) AS TotalSubscriptions
            FROM clientinfo
            GROUP BY Municipality"

            ' Query to count paid subscriptions for each municipality from payment
            Dim queryPaid As String = "
            SELECT Municipality, COUNT(*) AS PaidSubscriptions
            FROM payments
            WHERE MONTH(Dateofpayment) = @SelectedMonth AND YEAR(Dateofpayment) = @SelectedYear AND Payment > 0
            GROUP BY Municipality"

            ' DataTables for results
            Dim dtTotal As New DataTable
            Dim dtPaid As New DataTable

            ' Open connection and fetch data
            openConn(db_name)

            ' Execute the total subscriptions query
            Using cmdTotal As New MySqlCommand(queryTotal, conn)
                Using adapterTotal As New MySqlDataAdapter(cmdTotal)
                    adapterTotal.Fill(dtTotal)
                End Using
            End Using

            ' Execute the paid subscriptions query
            Using cmdPaid As New MySqlCommand(queryPaid, conn)
                cmdPaid.Parameters.AddWithValue("@SelectedMonth", selectedMonth)
                cmdPaid.Parameters.AddWithValue("@SelectedYear", selectedYear)

                Using adapterPaid As New MySqlDataAdapter(cmdPaid)
                    adapterPaid.Fill(dtPaid)
                End Using
            End Using

            ' Merge the data (left join TotalSubscriptions with PaidSubscriptions on Municipality)
            Dim resultTable As New DataTable
            resultTable.Columns.Add("Municipality", GetType(String))
            resultTable.Columns.Add("TotalSubscriptions", GetType(Integer))
            resultTable.Columns.Add("PaidSubscriptions", GetType(Integer))

            For Each totalRow As DataRow In dtTotal.Rows
                Dim municipality As String = totalRow("Municipality").ToString()
                Dim totalSubscriptions As Integer = Convert.ToInt32(totalRow("TotalSubscriptions"))

                ' Find corresponding PaidSubscriptions from the paid DataTable
                Dim paidRows = dtPaid.Select($"Municipality = '{municipality}'")
                Dim paidSubscriptions As Integer = If(paidRows.Length > 0, Convert.ToInt32(paidRows(0)("PaidSubscriptions")), 0)

                ' Add the merged row to the result table
                resultTable.Rows.Add(municipality, totalSubscriptions, paidSubscriptions)
            Next

            ' Configure the chart
            dvgclient.Series.Clear()

            ' Add data series for total subscriptions
            Dim totalSeries As New Series("Total Subscriptions")
            totalSeries.ChartType = SeriesChartType.Column
            totalSeries.IsValueShownAsLabel = True

            ' Add data series for paid subscriptions
            Dim paidSeries As New Series("Paid Subscriptions")
            paidSeries.ChartType = SeriesChartType.Column
            paidSeries.IsValueShownAsLabel = True

            ' Populate the series with data
            For Each row As DataRow In resultTable.Rows
                Dim municipality As String = row("Municipality").ToString()
                Dim totalSubscriptions As Integer = Convert.ToInt32(row("TotalSubscriptions"))
                Dim paidSubscriptions As Integer = Convert.ToInt32(row("PaidSubscriptions"))

                totalSeries.Points.AddXY(municipality, totalSubscriptions)
                paidSeries.Points.AddXY(municipality, paidSubscriptions)
            Next

            ' Add series to the chart
            dvgclient.Series.Add(totalSeries)
            dvgclient.Series.Add(paidSeries)

            ' Configure chart area
            Dim chartArea As ChartArea = dvgclient.ChartAreas(0)
            chartArea.AxisX.Title = "Municipality"
            chartArea.AxisY.Title = "Count"
            chartArea.AxisY.IsStartedFromZero = True
            chartArea.RecalculateAxesScale()

            chartArea.AxisX.LabelStyle.Angle = 90
            chartArea.AxisX.LabelStyle.IsStaggered = False
            chartArea.AxisX.Interval = 1
            chartArea.AxisX.LabelStyle.Font = New Font("Arial", 10, FontStyle.Regular)


        Catch ex As Exception
            MessageBox.Show($"Error loading chart data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RefreshGraph()
        LoadMunicipalityChart()
        SetupAutoRefresh()
        RefreshDashboard()
        Refresh()
    End Sub
End Class