﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.DataVisualization.Charting

Public Class AdminGraph1
    Dim count As Integer = 0
    Dim timer As New Timer()



    Private Sub AdminGraph1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
      
        Me.WindowState = FormWindowState.Maximized
        Try
            SetupAutoRefresh()
            RefreshDashboard()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Public Sub RefreshDashboard()
        LoadMunicipalityRevenueChart()

    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `payments`;")
            If newCount <> count Then
                count = newCount
                RefreshDashboard() ' Refresh the DataGridView if there are changes
                LoadMunicipalityRevenueChart()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `payments`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshDashboard()
                    LoadMunicipalityRevenueChart()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub LoadMunicipalityRevenueChart()
        Try

            Dim selectedMonth As Integer = dptdatepick.Value.Month
            Dim selectedYear As Integer = dptdatepick.Value.Year

            ' Query to calculate total revenue for each municipality from payments
            Dim queryRevenue As String = "
            SELECT Municipality, SUM(Payment) AS TotalRevenue FROM payments 
            WHERE MONTH(Dateofpayment) = @SelectedMonth AND YEAR(Dateofpayment) = @SelectedYear 
            GROUP BY Municipality"


            Dim dtRevenue As New DataTable
            Dim totalRevenue As Decimal = 0


            openConn(db_name)


            Using cmdRevenue As New MySqlCommand(queryRevenue, conn)
                cmdRevenue.Parameters.AddWithValue("@SelectedMonth", selectedMonth)
                cmdRevenue.Parameters.AddWithValue("@SelectedYear", selectedYear)

                Using adapterRevenue As New MySqlDataAdapter(cmdRevenue)
                    adapterRevenue.Fill(dtRevenue)
                End Using
            End Using


            dvgclient.Series.Clear()


            If dtRevenue.Rows.Count = 0 Then



                dvgclient.Series.Clear()
                Dim emptySeries As New Series("No Data")
                emptySeries.ChartType = SeriesChartType.Column
                dvgclient.Series.Add(emptySeries)

            Else

                Dim revenueSeries As New Series("Total Revenue")
                revenueSeries.ChartType = SeriesChartType.Column
                revenueSeries.IsValueShownAsLabel = True

                For Each row As DataRow In dtRevenue.Rows
                    Dim municipality As String = row("Municipality").ToString()
                    Dim municipalityRevenue As Decimal = Convert.ToDecimal(row("TotalRevenue"))


                    revenueSeries.Points.AddXY(municipality, municipalityRevenue)


                    totalRevenue += municipalityRevenue
                Next

                ' Add the series to the chart
                dvgclient.Series.Add(revenueSeries)

                ' Configure chart area
                Dim chartArea As ChartArea = dvgclient.ChartAreas(0)
                chartArea.AxisX.Title = "Municipality"
                chartArea.AxisY.Title = "Revenue (PHP)"
                chartArea.AxisY.IsStartedFromZero = True
                chartArea.RecalculateAxesScale()
            End If


            DisplayTotalRevenue(totalRevenue)

        Catch ex As Exception
            MessageBox.Show($"Error loading chart data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    Private Sub dptdatepick_ValueChanged(sender As Object, e As EventArgs) Handles dptdatepick.ValueChanged

        LoadMunicipalityRevenueChart()
    End Sub

    Private Sub DisplayTotalRevenue(totalRevenue As Decimal)
        txtotalrvenue.Text = "Total Revenue: " & totalRevenue.ToString("C2")
    End Sub

    Private Sub btnd_Click(sender As Object, e As EventArgs) Handles btnd.Click
        AdminDashboard.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        AdminReport.Show()

    End Sub

    Private Sub btnsubo_Click(sender As Object, e As EventArgs) Handles btnsubo.Click
        Adminsuboffer.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AdminFeedback.Show()
        Me.Hide()
    End Sub

    Private Sub btnci_Click(sender As Object, e As EventArgs) Handles btnci.Click
        AdminGraph.Show()
        Me.Hide()
    End Sub

    Private Sub btng_Click(sender As Object, e As EventArgs) Handles btng.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SetupAutoRefresh()
        RefreshDashboard()
        LoadMunicipalityRevenueChart()
    End Sub
End Class