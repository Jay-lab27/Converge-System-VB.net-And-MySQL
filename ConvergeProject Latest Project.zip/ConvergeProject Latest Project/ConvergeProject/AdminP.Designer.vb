﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminP
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnd = New System.Windows.Forms.Button()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btng = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btncrud = New System.Windows.Forms.Button()
        Me.btnp = New System.Windows.Forms.Button()
        Me.btnc = New System.Windows.Forms.Button()
        Me.btnci = New System.Windows.Forms.Button()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.btna = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.lblPaymentAmount = New System.Windows.Forms.Label()
        Me.lblCustomerID = New System.Windows.Forms.Label()
        Me.btnPay = New System.Windows.Forms.Button()
        Me.txtuname = New System.Windows.Forms.TextBox()
        Me.dvgclient = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtdue = New System.Windows.Forms.DateTimePicker()
        Me.dvgclient1 = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dvgclient2 = New System.Windows.Forms.DataGridView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtId = New System.Windows.Forms.TextBox()
        Me.txtmun = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtbar = New System.Windows.Forms.TextBox()
        Me.txtpurok = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtmname = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtname1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbzip = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cmblatefee = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtreqd = New System.Windows.Forms.RichTextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cmbprice = New System.Windows.Forms.TextBox()
        Me.btnsubo = New System.Windows.Forms.Button()
        Me.txtdatepayment = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dvgclient1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dvgclient2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(55, 636)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 79
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 20)
        Me.Label1.TabIndex = 78
        Me.Label1.Text = " Admin"
        '
        'btnd
        '
        Me.btnd.Location = New System.Drawing.Point(55, 132)
        Me.btnd.Name = "btnd"
        Me.btnd.Size = New System.Drawing.Size(83, 34)
        Me.btnd.TabIndex = 80
        Me.btnd.Text = "Dashboard"
        Me.btnd.UseVisualStyleBackColor = True
        '
        'btnr
        '
        Me.btnr.Location = New System.Drawing.Point(55, 244)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(83, 34)
        Me.btnr.TabIndex = 83
        Me.btnr.Text = "Report"
        Me.btnr.UseVisualStyleBackColor = True
        '
        'btng
        '
        Me.btng.Location = New System.Drawing.Point(55, 186)
        Me.btng.Name = "btng"
        Me.btng.Size = New System.Drawing.Size(83, 34)
        Me.btng.TabIndex = 82
        Me.btng.Text = "Graph"
        Me.btng.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(373, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 25)
        Me.Label3.TabIndex = 215
        Me.Label3.Text = "Payment"
        '
        'btncrud
        '
        Me.btncrud.Location = New System.Drawing.Point(766, 128)
        Me.btncrud.Name = "btncrud"
        Me.btncrud.Size = New System.Drawing.Size(105, 33)
        Me.btncrud.TabIndex = 212
        Me.btncrud.Text = "CRUD"
        Me.btncrud.UseVisualStyleBackColor = True
        '
        'btnp
        '
        Me.btnp.Location = New System.Drawing.Point(660, 128)
        Me.btnp.Name = "btnp"
        Me.btnp.Size = New System.Drawing.Size(74, 33)
        Me.btnp.TabIndex = 210
        Me.btnp.Text = "Payment"
        Me.btnp.UseVisualStyleBackColor = True
        '
        'btnc
        '
        Me.btnc.Location = New System.Drawing.Point(415, 128)
        Me.btnc.Name = "btnc"
        Me.btnc.Size = New System.Drawing.Size(103, 33)
        Me.btnc.TabIndex = 209
        Me.btnc.Text = "Client Subscription"
        Me.btnc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnc.UseVisualStyleBackColor = True
        '
        'btnci
        '
        Me.btnci.Location = New System.Drawing.Point(289, 128)
        Me.btnci.Name = "btnci"
        Me.btnci.Size = New System.Drawing.Size(105, 33)
        Me.btnci.TabIndex = 208
        Me.btnci.Text = "Client Information"
        Me.btnci.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(1020, 132)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(192, 26)
        Me.txtname.TabIndex = 206
        '
        'btna
        '
        Me.btna.Location = New System.Drawing.Point(547, 128)
        Me.btna.Name = "btna"
        Me.btna.Size = New System.Drawing.Size(83, 33)
        Me.btna.TabIndex = 204
        Me.btna.Text = "Appointment"
        Me.btna.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView2.Location = New System.Drawing.Point(244, 79)
        Me.DataGridView2.Margin = New System.Windows.Forms.Padding(1)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.Size = New System.Drawing.Size(996, 591)
        Me.DataGridView2.TabIndex = 213
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(1157, 103)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(83, 26)
        Me.btnsearch.TabIndex = 207
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'lblPaymentAmount
        '
        Me.lblPaymentAmount.AutoSize = True
        Me.lblPaymentAmount.BackColor = System.Drawing.Color.MediumAquamarine
        Me.lblPaymentAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaymentAmount.Location = New System.Drawing.Point(514, 270)
        Me.lblPaymentAmount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPaymentAmount.Name = "lblPaymentAmount"
        Me.lblPaymentAmount.Size = New System.Drawing.Size(111, 16)
        Me.lblPaymentAmount.TabIndex = 221
        Me.lblPaymentAmount.Text = "Payment Amount:"
        '
        'lblCustomerID
        '
        Me.lblCustomerID.AutoSize = True
        Me.lblCustomerID.BackColor = System.Drawing.Color.MediumAquamarine
        Me.lblCustomerID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerID.Location = New System.Drawing.Point(312, 269)
        Me.lblCustomerID.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCustomerID.Name = "lblCustomerID"
        Me.lblCustomerID.Size = New System.Drawing.Size(73, 16)
        Me.lblCustomerID.TabIndex = 220
        Me.lblCustomerID.Text = "Username:"
        '
        'btnPay
        '
        Me.btnPay.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPay.Location = New System.Drawing.Point(315, 600)
        Me.btnPay.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPay.Name = "btnPay"
        Me.btnPay.Size = New System.Drawing.Size(379, 30)
        Me.btnPay.TabIndex = 219
        Me.btnPay.Text = "Paid"
        Me.btnPay.UseVisualStyleBackColor = False
        '
        'txtuname
        '
        Me.txtuname.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtuname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtuname.Location = New System.Drawing.Point(315, 289)
        Me.txtuname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtuname.Name = "txtuname"
        Me.txtuname.Size = New System.Drawing.Size(180, 22)
        Me.txtuname.TabIndex = 217
        '
        'dvgclient
        '
        Me.dvgclient.AllowUserToAddRows = False
        Me.dvgclient.AllowUserToDeleteRows = False
        Me.dvgclient.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient.Location = New System.Drawing.Point(742, 468)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.ReadOnly = True
        Me.dvgclient.Size = New System.Drawing.Size(230, 175)
        Me.dvgclient.TabIndex = 223
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(518, 361)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 16)
        Me.Label2.TabIndex = 225
        Me.Label2.Text = "Due Date:"
        '
        'txtdue
        '
        Me.txtdue.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdue.Location = New System.Drawing.Point(516, 379)
        Me.txtdue.Margin = New System.Windows.Forms.Padding(2)
        Me.txtdue.Name = "txtdue"
        Me.txtdue.Size = New System.Drawing.Size(176, 22)
        Me.txtdue.TabIndex = 226
        '
        'dvgclient1
        '
        Me.dvgclient1.AllowUserToAddRows = False
        Me.dvgclient1.AllowUserToDeleteRows = False
        Me.dvgclient1.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient1.Location = New System.Drawing.Point(988, 468)
        Me.dvgclient1.Name = "dvgclient1"
        Me.dvgclient1.ReadOnly = True
        Me.dvgclient1.Size = New System.Drawing.Size(224, 175)
        Me.dvgclient1.TabIndex = 228
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.LightSlateGray
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(795, 445)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(126, 16)
        Me.Label5.TabIndex = 231
        Me.Label5.Text = "Client Information"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.LightSlateGray
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(454, 192)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 16)
        Me.Label6.TabIndex = 233
        Me.Label6.Text = "Client Payment"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.LightSlateGray
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(1036, 444)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 16)
        Me.Label4.TabIndex = 229
        Me.Label4.Text = "Client Subscription"
        '
        'dvgclient2
        '
        Me.dvgclient2.AllowUserToAddRows = False
        Me.dvgclient2.AllowUserToDeleteRows = False
        Me.dvgclient2.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient2.Location = New System.Drawing.Point(742, 220)
        Me.dvgclient2.Name = "dvgclient2"
        Me.dvgclient2.ReadOnly = True
        Me.dvgclient2.Size = New System.Drawing.Size(470, 198)
        Me.dvgclient2.TabIndex = 235
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.LightSlateGray
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(923, 193)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(122, 16)
        Me.Label7.TabIndex = 236
        Me.Label7.Text = "Payment Record"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(312, 226)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 16)
        Me.Label8.TabIndex = 239
        Me.Label8.Text = "User ID:"
        '
        'txtId
        '
        Me.txtId.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtId.Location = New System.Drawing.Point(315, 244)
        Me.txtId.Margin = New System.Windows.Forms.Padding(2)
        Me.txtId.Name = "txtId"
        Me.txtId.Size = New System.Drawing.Size(180, 22)
        Me.txtId.TabIndex = 238
        '
        'txtmun
        '
        Me.txtmun.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtmun.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmun.FormattingEnabled = True
        Me.txtmun.Items.AddRange(New Object() {"Daet", "Mercedes", "Labo", "Basud", "San Lorenzo Ruiz", "Talisay", "Vinzons", "Jose Panganiban", "Paracale", "Capalonga", "San Vicente", "Sta. Elena"})
        Me.txtmun.Location = New System.Drawing.Point(313, 552)
        Me.txtmun.Margin = New System.Windows.Forms.Padding(2)
        Me.txtmun.Name = "txtmun"
        Me.txtmun.Size = New System.Drawing.Size(180, 24)
        Me.txtmun.TabIndex = 243
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(312, 536)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 16)
        Me.Label10.TabIndex = 242
        Me.Label10.Text = "Municipality:"
        '
        'txtbar
        '
        Me.txtbar.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtbar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbar.Location = New System.Drawing.Point(313, 509)
        Me.txtbar.Name = "txtbar"
        Me.txtbar.Size = New System.Drawing.Size(182, 22)
        Me.txtbar.TabIndex = 254
        '
        'txtpurok
        '
        Me.txtpurok.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtpurok.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpurok.Location = New System.Drawing.Point(313, 465)
        Me.txtpurok.Name = "txtpurok"
        Me.txtpurok.Size = New System.Drawing.Size(182, 22)
        Me.txtpurok.TabIndex = 253
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(312, 449)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 16)
        Me.Label16.TabIndex = 252
        Me.Label16.Text = "Purok:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(310, 490)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 16)
        Me.Label15.TabIndex = 251
        Me.Label15.Text = "Barangay:"
        '
        'txtmname
        '
        Me.txtmname.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtmname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmname.Location = New System.Drawing.Point(315, 425)
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(180, 22)
        Me.txtmname.TabIndex = 250
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(314, 404)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(91, 16)
        Me.Label14.TabIndex = 249
        Me.Label14.Text = "Middle Name:"
        '
        'txtfname
        '
        Me.txtfname.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtfname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfname.Location = New System.Drawing.Point(316, 379)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(179, 22)
        Me.txtfname.TabIndex = 248
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(313, 360)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(75, 16)
        Me.Label13.TabIndex = 247
        Me.Label13.Text = "First Name:"
        '
        'txtname1
        '
        Me.txtname1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtname1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname1.Location = New System.Drawing.Point(316, 335)
        Me.txtname1.Name = "txtname1"
        Me.txtname1.Size = New System.Drawing.Size(179, 22)
        Me.txtname1.TabIndex = 246
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(313, 316)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 16)
        Me.Label11.TabIndex = 245
        Me.Label11.Text = "Last Name:"
        '
        'cmbzip
        '
        Me.cmbzip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbzip.FormattingEnabled = True
        Me.cmbzip.Items.AddRange(New Object() {"", "4600", "4601", "4604", "4608", "4602", "4603", "4606", "4605", "4609", " 4611"})
        Me.cmbzip.Location = New System.Drawing.Point(517, 242)
        Me.cmbzip.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbzip.Name = "cmbzip"
        Me.cmbzip.Size = New System.Drawing.Size(177, 23)
        Me.cmbzip.TabIndex = 256
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(514, 226)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 16)
        Me.Label12.TabIndex = 255
        Me.Label12.Text = "Zip Code:"
        '
        'cmblatefee
        '
        Me.cmblatefee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmblatefee.FormattingEnabled = True
        Me.cmblatefee.Items.AddRange(New Object() {"0", "30", "60", "90", "120", "150", "180", "210", "240", "270", "300"})
        Me.cmblatefee.Location = New System.Drawing.Point(516, 425)
        Me.cmblatefee.Name = "cmblatefee"
        Me.cmblatefee.Size = New System.Drawing.Size(176, 24)
        Me.cmblatefee.TabIndex = 258
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(516, 406)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(146, 16)
        Me.Label17.TabIndex = 257
        Me.Label17.Text = "Late Payment Charges:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(515, 454)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(95, 16)
        Me.Label18.TabIndex = 259
        Me.Label18.Text = "Payment Note:"
        '
        'txtreqd
        '
        Me.txtreqd.Location = New System.Drawing.Point(517, 476)
        Me.txtreqd.Name = "txtreqd"
        Me.txtreqd.Size = New System.Drawing.Size(178, 100)
        Me.txtreqd.TabIndex = 260
        Me.txtreqd.Text = ""
        '
        'cmbprice
        '
        Me.cmbprice.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.cmbprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbprice.Location = New System.Drawing.Point(517, 289)
        Me.cmbprice.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbprice.Name = "cmbprice"
        Me.cmbprice.Size = New System.Drawing.Size(180, 22)
        Me.cmbprice.TabIndex = 261
        '
        'btnsubo
        '
        Me.btnsubo.Location = New System.Drawing.Point(55, 298)
        Me.btnsubo.Name = "btnsubo"
        Me.btnsubo.Size = New System.Drawing.Size(83, 34)
        Me.btnsubo.TabIndex = 262
        Me.btnsubo.Text = "Subscription Offer"
        Me.btnsubo.UseVisualStyleBackColor = True
        '
        'txtdatepayment
        '
        Me.txtdatepayment.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdatepayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdatepayment.Location = New System.Drawing.Point(516, 335)
        Me.txtdatepayment.Margin = New System.Windows.Forms.Padding(2)
        Me.txtdatepayment.Name = "txtdatepayment"
        Me.txtdatepayment.Size = New System.Drawing.Size(177, 22)
        Me.txtdatepayment.TabIndex = 241
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(516, 318)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(109, 16)
        Me.Label9.TabIndex = 240
        Me.Label9.Text = "Date of Payment:"
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.LightSlateGray
        Me.PictureBox9.Location = New System.Drawing.Point(742, 184)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(470, 36)
        Me.PictureBox9.TabIndex = 237
        Me.PictureBox9.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.LightSlateGray
        Me.PictureBox5.Location = New System.Drawing.Point(742, 438)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(230, 30)
        Me.PictureBox5.TabIndex = 232
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.LightSlateGray
        Me.PictureBox4.Location = New System.Drawing.Point(988, 438)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(224, 30)
        Me.PictureBox4.TabIndex = 230
        Me.PictureBox4.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox8.Location = New System.Drawing.Point(314, 55)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(214, 48)
        Me.PictureBox8.TabIndex = 216
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.ConvergeProject.My.Resources.Resources.search_icon_png_21
        Me.PictureBox7.Location = New System.Drawing.Point(993, 132)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 214
        Me.PictureBox7.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(32, 47)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 77
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(0, -3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 707)
        Me.PictureBox2.TabIndex = 76
        Me.PictureBox2.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.LightSlateGray
        Me.PictureBox6.Location = New System.Drawing.Point(285, 182)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(437, 38)
        Me.PictureBox6.TabIndex = 234
        Me.PictureBox6.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox3.Location = New System.Drawing.Point(285, 182)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(437, 461)
        Me.PictureBox3.TabIndex = 222
        Me.PictureBox3.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(55, 352)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 34)
        Me.Button2.TabIndex = 263
        Me.Button2.Text = "Feedback "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1129, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 313
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'AdminP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1311, 702)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnsubo)
        Me.Controls.Add(Me.cmbprice)
        Me.Controls.Add(Me.txtreqd)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.cmblatefee)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.cmbzip)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtbar)
        Me.Controls.Add(Me.txtpurok)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtmname)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtfname)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtname1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtmun)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtdatepayment)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtdue)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblPaymentAmount)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtId)
        Me.Controls.Add(Me.lblCustomerID)
        Me.Controls.Add(Me.txtuname)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.dvgclient2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.dvgclient1)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.btnPay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.btncrud)
        Me.Controls.Add(Me.btnp)
        Me.Controls.Add(Me.btnc)
        Me.Controls.Add(Me.btnci)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.btna)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btng)
        Me.Controls.Add(Me.btnd)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "AdminP"
        Me.Text = "DashboardSAP"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dvgclient1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dvgclient2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnlogout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnd As Button
    Friend WithEvents btnr As Button
    Friend WithEvents btng As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents btncrud As Button
    Friend WithEvents btnp As Button
    Friend WithEvents btnc As Button
    Friend WithEvents btnci As Button
    Friend WithEvents txtname As TextBox
    Friend WithEvents btna As Button
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents btnsearch As Button
    Friend WithEvents lblPaymentAmount As Label
    Friend WithEvents lblCustomerID As Label
    Friend WithEvents btnPay As Button
    Friend WithEvents txtuname As TextBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents dvgclient As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents txtdue As DateTimePicker
    Friend WithEvents dvgclient1 As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents dvgclient2 As DataGridView
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtId As TextBox
    Friend WithEvents txtmun As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtbar As TextBox
    Friend WithEvents txtpurok As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txtmname As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtfname As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtname1 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents cmbzip As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents cmblatefee As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtreqd As RichTextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents cmbprice As TextBox
    Friend WithEvents btnsubo As Button
    Friend WithEvents txtdatepayment As DateTimePicker
    Friend WithEvents Label9 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
