﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GraphSA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btng = New System.Windows.Forms.Button()
        Me.btnd = New System.Windows.Forms.Button()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.dvgclient = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.btnci = New System.Windows.Forms.Button()
        Me.btna = New System.Windows.Forms.Button()
        Me.dptdatepick = New System.Windows.Forms.DateTimePicker()
        Me.btnlogs = New System.Windows.Forms.Button()
        Me.btnsubo = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(370, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 25)
        Me.Label4.TabIndex = 183
        Me.Label4.Text = "Total Client"
        '
        'btnr
        '
        Me.btnr.Location = New System.Drawing.Point(52, 246)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(83, 34)
        Me.btnr.TabIndex = 172
        Me.btnr.Text = "Report"
        Me.btnr.UseVisualStyleBackColor = True
        '
        'btng
        '
        Me.btng.Location = New System.Drawing.Point(52, 188)
        Me.btng.Name = "btng"
        Me.btng.Size = New System.Drawing.Size(83, 34)
        Me.btng.TabIndex = 171
        Me.btng.Text = "Graph"
        Me.btng.UseVisualStyleBackColor = True
        '
        'btnd
        '
        Me.btnd.Location = New System.Drawing.Point(52, 134)
        Me.btnd.Name = "btnd"
        Me.btnd.Size = New System.Drawing.Size(83, 34)
        Me.btnd.TabIndex = 169
        Me.btnd.Text = "Dashboard"
        Me.btnd.UseVisualStyleBackColor = True
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(52, 638)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 168
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(48, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 20)
        Me.Label1.TabIndex = 167
        Me.Label1.Text = "Super Admin"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.Location = New System.Drawing.Point(265, 92)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(1)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(996, 580)
        Me.DataGridView1.TabIndex = 181
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(958, 95)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(83, 33)
        Me.btnsearch.TabIndex = 175
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'dvgclient
        '
        ChartArea2.Name = "ChartArea1"
        Me.dvgclient.ChartAreas.Add(ChartArea2)
        Legend2.Name = "Legend1"
        Me.dvgclient.Legends.Add(Legend2)
        Me.dvgclient.Location = New System.Drawing.Point(332, 179)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel
        Series2.ChartArea = "ChartArea1"
        Series2.Legend = "Legend1"
        Series2.Name = "Series1"
        Me.dvgclient.Series.Add(Series2)
        Me.dvgclient.Size = New System.Drawing.Size(875, 422)
        Me.dvgclient.TabIndex = 185
        Me.dvgclient.Text = "Chart1"
        '
        'lblcount
        '
        Me.lblcount.AutoSize = True
        Me.lblcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(332, 601)
        Me.lblcount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(57, 20)
        Me.lblcount.TabIndex = 186
        Me.lblcount.Text = "Label2"
        '
        'btnci
        '
        Me.btnci.Location = New System.Drawing.Point(378, 128)
        Me.btnci.Name = "btnci"
        Me.btnci.Size = New System.Drawing.Size(105, 33)
        Me.btnci.TabIndex = 188
        Me.btnci.Text = "Total Client"
        Me.btnci.UseVisualStyleBackColor = True
        '
        'btna
        '
        Me.btna.Location = New System.Drawing.Point(517, 128)
        Me.btna.Name = "btna"
        Me.btna.Size = New System.Drawing.Size(83, 33)
        Me.btna.TabIndex = 187
        Me.btna.Text = "Revenue"
        Me.btna.UseVisualStyleBackColor = True
        '
        'dptdatepick
        '
        Me.dptdatepick.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dptdatepick.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dptdatepick.Location = New System.Drawing.Point(936, 128)
        Me.dptdatepick.Name = "dptdatepick"
        Me.dptdatepick.Size = New System.Drawing.Size(271, 26)
        Me.dptdatepick.TabIndex = 189
        '
        'btnlogs
        '
        Me.btnlogs.Location = New System.Drawing.Point(52, 304)
        Me.btnlogs.Name = "btnlogs"
        Me.btnlogs.Size = New System.Drawing.Size(83, 34)
        Me.btnlogs.TabIndex = 190
        Me.btnlogs.Text = "Logs"
        Me.btnlogs.UseVisualStyleBackColor = True
        '
        'btnsubo
        '
        Me.btnsubo.Location = New System.Drawing.Point(52, 362)
        Me.btnsubo.Name = "btnsubo"
        Me.btnsubo.Size = New System.Drawing.Size(83, 34)
        Me.btnsubo.TabIndex = 191
        Me.btnsubo.Text = "Subscription Offer"
        Me.btnsubo.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(52, 420)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 34)
        Me.Button2.TabIndex = 192
        Me.Button2.Text = "Feedback "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox4.Location = New System.Drawing.Point(322, 62)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(213, 48)
        Me.PictureBox4.TabIndex = 184
        Me.PictureBox4.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(29, 49)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 166
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(-3, -1)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 707)
        Me.PictureBox2.TabIndex = 165
        Me.PictureBox2.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1144, 48)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 267
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GraphSA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1316, 704)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnsubo)
        Me.Controls.Add(Me.btnlogs)
        Me.Controls.Add(Me.dptdatepick)
        Me.Controls.Add(Me.btnci)
        Me.Controls.Add(Me.btna)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btng)
        Me.Controls.Add(Me.btnd)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "GraphSA"
        Me.Text = "GraphSA"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnr As Button
    Friend WithEvents btng As Button
    Friend WithEvents btnd As Button
    Friend WithEvents btnlogout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnsearch As Button
    Friend WithEvents dvgclient As DataVisualization.Charting.Chart
    Friend WithEvents lblcount As Label
    Friend WithEvents btnci As Button
    Friend WithEvents btna As Button
    Friend WithEvents dptdatepick As DateTimePicker
    Friend WithEvents btnlogs As Button
    Friend WithEvents btnsubo As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
