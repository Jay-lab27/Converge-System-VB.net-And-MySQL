﻿Imports MySql.Data.MySqlClient

Public Class AdminCrud


    Dim count As Integer = 0

    Dim timer As New Timer()

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `clientinfo`;")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `clientinfo`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub



    Private Sub RefreshData()
        Try

            count = LoadToDGV("SELECT * FROM `clientinfo`;", dvgclient)

            lblcount.Text = "Total Records: " & count
            'if i dont want to display ID
            dvgclient.Columns(2).Visible = False

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub




    Private Sub btnclear_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub AdminCrud_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Maximized
        Try
            SetupAutoRefresh()
            RefreshDashboard()
            RefreshData()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `clientinfo` WHERE CONCAT(Lastname, ' ', Username, ' ', Municipality) LIKE '%" & txtname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnadd_Click_1(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            ' Validate inputs
            If txtuname.Text.Trim = Nothing Then
                MsgBox("Enter Username.")
                txtuname.Focus()
                Exit Sub
            End If
            If txtpass.Text.Trim = Nothing Then
                MsgBox("Enter Password.")
                txtpass.Focus()
                Exit Sub
            End If
            If txtname1.Text.Trim = Nothing Then
                MsgBox("Enter Lastname.")
                txtname1.Focus()
                Exit Sub
            End If
            If txtfname.Text.Trim = Nothing Then
                MsgBox("Enter Firstname.")
                txtfname.Focus()
                Exit Sub
            End If
            If txtmname.Text.Trim = Nothing Then
                MsgBox("Enter Middlename.")
                txtmname.Focus()
                Exit Sub
            End If
            If cmbsex.Text.Trim = Nothing Then
                MsgBox("Enter Sex.")
                cmbsex.Focus()
                Exit Sub
            End If
            If Bdate.Text.Trim = Nothing Then
                MsgBox("Enter Birthdate.")
                Bdate.Focus()
                Exit Sub
            End If
            If txtmarital.Text.Trim = Nothing Then
                MsgBox("Enter Marital Status.")
                txtmarital.Focus()
                Exit Sub
            End If
            If txtpurok.Text.Trim = Nothing Then
                MsgBox("Enter Purok.")
                txtpurok.Focus()
                Exit Sub
            End If
            If txtbar.Text.Trim = Nothing Then
                MsgBox("Enter Barangay.")
                txtbar.Focus()
                Exit Sub
            End If
            If txtmun.Text.Trim = Nothing Then
                MsgBox("Enter Municipality.")
                txtmun.Focus()
                Exit Sub
            End If
            If cmbzip.Text.Trim = Nothing Then
                MsgBox("Enter Zipcode.")
                cmbzip.Focus()
                Exit Sub
            End If
            If txtnum.Text.Trim = Nothing Then
                MsgBox("Enter Contact Number.")
                txtnum.Focus()
                Exit Sub
            End If
            If String.IsNullOrWhiteSpace(txtgmail.Text) Then
                MsgBox("Enter Gmail.")
                txtgmail.Focus()
                Exit Sub
            End If

            Dim gmailPattern As String = "^[a-zA-Z0-9._%+-]+@gmail\.com$"
            Dim emailRegex As New System.Text.RegularExpressions.Regex(gmailPattern)

            If Not emailRegex.IsMatch(txtgmail.Text.Trim) Then
                MsgBox("Please enter a valid Gmail address (e.g., username@gmail.com).")
                txtgmail.Focus()
                Exit Sub
            End If

            ' Check if username already exists
            Dim checkQuery As String = "SELECT COUNT(*) FROM clientinfo WHERE Username = @Username"
            Dim cmd As New MySqlCommand(checkQuery, conn)
            cmd.Parameters.AddWithValue("@Username", txtuname.Text.Trim())

            Dim usernameExists As Integer = Convert.ToInt32(cmd.ExecuteScalar())

            If usernameExists > 0 Then
                MsgBox("Username already exists. Please make a different username.", MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' Encrypt the password before saving
            Dim encryptedPassword As String = Encrypt(txtpass.Text.Trim)

            ' Confirm save
            If MsgBox("Are you sure you want to save this record with the name of: " & txtname1.Text.Trim & "?", MsgBoxStyle.YesNo, "Save") = MsgBoxResult.Yes Then
                ' Execute the query with the encrypted password
                readQuery(String.Format("INSERT INTO `clientinfo` (`Username`, `Password`, `Lastname`, `Firstname`, `Middlename`, `Sex`, `Birthdate`, `MaritalStatus`, `Purok`, `Barangay`, `Municipality`, `Zipcode`, `ContactNo`, `Gmail`) " &
                                    "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6:yyyy-MM-dd}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}')",
                                    txtuname.Text.Trim, encryptedPassword, txtname1.Text.Trim, txtfname.Text.Trim, txtmname.Text.Trim,
                                    cmbsex.Text.Trim, Bdate.Value.ToString("yyyy-MM-dd"), txtmarital.Text.Trim, txtpurok.Text.Trim, txtbar.Text.Trim, txtmun.Text.Trim,
                                    cmbzip.Text.Trim, txtnum.Text.Trim, txtgmail.Text.Trim))

                MsgBox("Saved!")
                RefreshData()

                Log("Saved new client" & "by: " & CurrentLoggedUser.username, "btnadd_Click")
                CrudSAsubscription.Show()
                Dim dashboard As DashboardSA = CType(Application.OpenForms("DashboardSA"), DashboardSA)
                If dashboard IsNot Nothing Then
                    dashboard.RefreshDashboard() ' Call the refresh method
                End If

                Dim dashboard1 As DashboardSAP = CType(Application.OpenForms(" DashboardSAP"), DashboardSAP)
                If dashboard1 IsNot Nothing Then
                    dashboard1.RefreshDashboard() ' Call the refresh method
                End If

                GraphSA.RefreshGraph()



                ' Show subscription form or next step
                CrudSAsubscription.Show()
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click

        Try
            AdminDashboard.Show()
            Me.Hide()


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dvgclient_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgclient.CellContentDoubleClick
        Try

            If e.RowIndex >= 0 Then

                txtuname.Tag = dvgclient.Rows(e.RowIndex).Cells(0).Value
                txtuname.Text = dvgclient.Rows(e.RowIndex).Cells(1).Value.ToString()
                txtpass.Text = dvgclient.Rows(e.RowIndex).Cells(2).Value.ToString()
                txtname1.Text = dvgclient.Rows(e.RowIndex).Cells(3).Value.ToString()
                txtfname.Text = dvgclient.Rows(e.RowIndex).Cells(4).Value.ToString()
                txtmname.Text = dvgclient.Rows(e.RowIndex).Cells(5).Value.ToString()
                cmbsex.Text = dvgclient.Rows(e.RowIndex).Cells(6).Value.ToString()
                Bdate.Value = Convert.ToDateTime(dvgclient.Rows(e.RowIndex).Cells(7).Value)
                txtmarital.Text = dvgclient.Rows(e.RowIndex).Cells(8).Value.ToString()
                txtpurok.Text = dvgclient.Rows(e.RowIndex).Cells(9).Value.ToString()
                txtbar.Text = dvgclient.Rows(e.RowIndex).Cells(10).Value.ToString()
                txtmun.Text = dvgclient.Rows(e.RowIndex).Cells(11).Value.ToString()
                cmbzip.Text = dvgclient.Rows(e.RowIndex).Cells(12).Value.ToString()
                txtnum.Text = dvgclient.Rows(e.RowIndex).Cells(13).Value.ToString()
                txtgmail.Text = dvgclient.Rows(e.RowIndex).Cells(14).Value.ToString()
            End If
        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnupdate_Click_1(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            ' Validate inputs for required fields in the updated table structure
            If txtuname.Text.Trim = Nothing Then
                MsgBox("Enter Username.")
                txtuname.Focus()
                Exit Sub
            End If
            If txtpass.Text.Trim = Nothing Then
                MsgBox("Enter Password.")
                txtpass.Focus()
                Exit Sub
            End If
            If txtname1.Text.Trim = Nothing Then
                MsgBox("Enter Lastname.")
                txtname1.Focus()
                Exit Sub
            End If
            If txtfname.Text.Trim = Nothing Then
                MsgBox("Enter Firstname.")
                txtfname.Focus()
                Exit Sub
            End If
            If txtmname.Text.Trim = Nothing Then
                MsgBox("Enter Middlename.")
                txtmname.Focus()
                Exit Sub
            End If
            If cmbsex.Text.Trim = Nothing Then
                MsgBox("Pick a Sex.")
                cmbsex.Focus()
                Exit Sub
            End If
            If Bdate.Text.Trim = Nothing Then
                MsgBox("Select a Birth Date.")
                Bdate.Focus()
                Exit Sub
            End If
            If txtmarital.Text.Trim = Nothing Then
                MsgBox("Enter Marital Status.")
                txtmarital.Focus()
                Exit Sub
            End If
            If txtpurok.Text.Trim = Nothing Then
                MsgBox("Enter Purok.")
                txtpurok.Focus()
                Exit Sub
            End If
            If txtbar.Text.Trim = Nothing Then
                MsgBox("Enter Barangay.")
                txtbar.Focus()
                Exit Sub
            End If
            If txtmun.Text.Trim = Nothing Then
                MsgBox("Enter Municipality.")
                txtmun.Focus()
                Exit Sub
            End If
            If cmbzip.Text.Trim = Nothing Then
                MsgBox("Enter Zipcode.")
                cmbzip.Focus()
                Exit Sub
            End If
            If txtnum.Text.Trim = Nothing Then
                MsgBox("Enter Contact Number.")
                txtnum.Focus()
                Exit Sub
            End If
            If txtgmail.Text.Trim = Nothing Then
                MsgBox("Enter Gmail.")
                txtgmail.Focus()
                Exit Sub
            End If
            ' Check if username already exists
            Dim checkQuery As String = "SELECT COUNT(*) FROM clientinfo WHERE Username = @Username"
            Dim cmd As New MySqlCommand(checkQuery, conn)
            cmd.Parameters.AddWithValue("@Username", txtuname.Text.Trim())

            Dim usernameExists As Integer = Convert.ToInt32(cmd.ExecuteScalar())

            If usernameExists > 0 Then
                MsgBox("Username already exists. Please make a different username.", MsgBoxStyle.Critical)
                Exit Sub
            End If

            ' Confirmation prompt
            If MsgBox("Are you sure you want to update this record with the name: " & txtname1.Text.Trim & "?", MsgBoxStyle.YesNo, "Update") = MsgBoxResult.Yes Then
                ' Update query aligned with the updated table structure
                readQuery(String.Format("UPDATE `clientinfo` SET `Username`='{0}', `Password`='{1}', `Lastname`='{2}', `Firstname`='{3}', `Middlename`='{4}', `Sex`='{5}', `Birthdate`='{6:yyyy-MM-dd}', `MaritalStatus`='{7}', `Purok`='{8}', `Barangay`='{9}', `Municipality`='{10}', `Zipcode`='{11}', `ContactNo`='{12}', `Gmail`='{13}' WHERE `Id`={14}",
                            txtuname.Text, txtpass.Text, txtname1.Text, txtfname.Text, txtmname.Text, cmbsex.Text, Bdate.Value, txtmarital.Text, txtpurok.Text, txtbar.Text, txtmun.Text, cmbzip.Text, txtnum.Text, txtgmail.Text, txtuname.Tag))

                ' Notify success and refresh data
                MsgBox("Updated successfully.")

                RefreshData()
                Log("Update an client information" & "by: " & CurrentLoggedUser.username, "btnupdate_Click")
            End If
            Dim dashboard As DashboardSA = CType(Application.OpenForms("DashboardSA"), DashboardSA)
            If dashboard IsNot Nothing Then
                dashboard.RefreshDashboard() ' Call the refresh method
            End If

            Dim dashboard1 As DashboardSAP = CType(Application.OpenForms(" DashboardSAP"), DashboardSAP)
            If dashboard1 IsNot Nothing Then
                dashboard1.RefreshDashboard() ' Call the refresh method
            End If
            GraphSA.RefreshGraph()

        Catch ex As Exception
            ' Handle errors
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnclear_Click_1(sender As Object, e As EventArgs) Handles btnclear.Click
        Try
            ' Clear the text in each textbox
            txtuname.Clear()
            txtpass.Clear()
            txtname1.Clear()
            txtfname.Clear()
            txtmname.Clear()
            cmbsex.SelectedIndex = -1  ' Reset the ComboBox
            Bdate.Value = DateTime.Now ' Reset the DateTimePicker to the current date
            txtpurok.Clear()
            txtbar.Clear()
            txtnum.Clear()
            txtgmail.Clear()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            If MsgBox("Are you sure you want to delete record with the name of: " & txtuname.Tag & ": " & txtuname.Text & " " & txtuname.Text & "?", MsgBoxStyle.YesNo, "DELETE") = MsgBoxResult.Yes Then
                readQuery("DELETE FROM `clientinfo` WHERE `Id`=" & txtuname.Tag)
                MsgBox("Delete")
                RefreshData()
            End If
            Dim dashboard As DashboardSA = CType(Application.OpenForms("DashboardSA"), DashboardSA)
            If dashboard IsNot Nothing Then
                dashboard.RefreshDashboard() ' Call the refresh method
            End If

            Dim dashboard1 As DashboardSAP = CType(Application.OpenForms(" DashboardSAP"), DashboardSAP)
            If dashboard1 IsNot Nothing Then
                dashboard1.RefreshDashboard() ' Call the refresh method
            End If
            Dim dashboard2 As GraphSA = CType(Application.OpenForms(" GraphSA"), GraphSA)
            If dashboard2 IsNot Nothing Then
                dashboard2.RefreshDashboard() ' Call the refresh method
            End If
            GraphSA.RefreshGraph()
            Log("Delete an customer" & "by: " & CurrentLoggedUser.username, "btndelete_Click")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnsub_Click(sender As Object, e As EventArgs) Handles btnsub.Click
        AdminCrudsub.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SetupAutoRefresh()
        RefreshDashboard()
        RefreshData()
    End Sub
End Class