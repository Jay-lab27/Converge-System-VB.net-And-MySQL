﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Adminsub
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnback = New System.Windows.Forms.Button()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.dvgclient = New System.Windows.Forms.DataGridView()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.txtspeed = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtset = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbprice = New System.Windows.Forms.TextBox()
        Me.cmbsub = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtsubid = New System.Windows.Forms.TextBox()
        Me.txtsub = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dvgclient1 = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dvgclient1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnback
        '
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.Location = New System.Drawing.Point(24, 18)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(101, 32)
        Me.btnback.TabIndex = 154
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnupdate
        '
        Me.btnupdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(646, 203)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(197, 26)
        Me.btnupdate.TabIndex = 151
        Me.btnupdate.Text = "Update"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Location = New System.Drawing.Point(827, 107)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(94, 28)
        Me.btnsearch.TabIndex = 150
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(957, 95)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(256, 26)
        Me.txtname.TabIndex = 149
        '
        'dvgclient
        '
        Me.dvgclient.AllowUserToAddRows = False
        Me.dvgclient.AllowUserToDeleteRows = False
        Me.dvgclient.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient.Location = New System.Drawing.Point(144, 283)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.ReadOnly = True
        Me.dvgclient.RowHeadersWidth = 51
        Me.dvgclient.Size = New System.Drawing.Size(511, 266)
        Me.dvgclient.TabIndex = 141
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox4.Location = New System.Drawing.Point(91, 76)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(1140, 533)
        Me.PictureBox4.TabIndex = 165
        Me.PictureBox4.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(235, 62)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(192, 25)
        Me.Label7.TabIndex = 167
        Me.Label7.Text = "Client Subscription"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox3.Location = New System.Drawing.Point(187, 52)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(277, 48)
        Me.PictureBox3.TabIndex = 168
        Me.PictureBox3.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.ConvergeProject.My.Resources.Resources.search_icon_png_21
        Me.PictureBox7.Location = New System.Drawing.Point(929, 95)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 215
        Me.PictureBox7.TabStop = False
        '
        'txtspeed
        '
        Me.txtspeed.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtspeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtspeed.Location = New System.Drawing.Point(402, 203)
        Me.txtspeed.Margin = New System.Windows.Forms.Padding(2)
        Me.txtspeed.Name = "txtspeed"
        Me.txtspeed.Size = New System.Drawing.Size(197, 26)
        Me.txtspeed.TabIndex = 280
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(403, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 279
        Me.Label4.Text = "Speed:"
        '
        'txtset
        '
        Me.txtset.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtset.Location = New System.Drawing.Point(646, 140)
        Me.txtset.Margin = New System.Windows.Forms.Padding(2)
        Me.txtset.Name = "txtset"
        Me.txtset.Size = New System.Drawing.Size(197, 26)
        Me.txtset.TabIndex = 278
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(648, 118)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 20)
        Me.Label6.TabIndex = 277
        Me.Label6.Text = "Set up fee:"
        '
        'cmbprice
        '
        Me.cmbprice.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.cmbprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbprice.Location = New System.Drawing.Point(147, 203)
        Me.cmbprice.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbprice.Name = "cmbprice"
        Me.cmbprice.Size = New System.Drawing.Size(197, 26)
        Me.cmbprice.TabIndex = 276
        '
        'cmbsub
        '
        Me.cmbsub.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.cmbsub.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsub.Location = New System.Drawing.Point(399, 141)
        Me.cmbsub.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbsub.Name = "cmbsub"
        Me.cmbsub.Size = New System.Drawing.Size(197, 26)
        Me.cmbsub.TabIndex = 275
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(143, 119)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 20)
        Me.Label2.TabIndex = 274
        Me.Label2.Text = "Sub ID:"
        '
        'txtsubid
        '
        Me.txtsubid.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtsubid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsubid.Location = New System.Drawing.Point(144, 141)
        Me.txtsubid.Margin = New System.Windows.Forms.Padding(2)
        Me.txtsubid.Name = "txtsubid"
        Me.txtsubid.Size = New System.Drawing.Size(197, 26)
        Me.txtsubid.TabIndex = 273
        '
        'txtsub
        '
        Me.txtsub.AutoSize = True
        Me.txtsub.BackColor = System.Drawing.SystemColors.Control
        Me.txtsub.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub.Location = New System.Drawing.Point(398, 119)
        Me.txtsub.Name = "txtsub"
        Me.txtsub.Size = New System.Drawing.Size(101, 20)
        Me.txtsub.TabIndex = 272
        Me.txtsub.Text = "Subscription:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(150, 181)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(158, 20)
        Me.Label1.TabIndex = 271
        Me.Label1.Text = "Price of Subscription:"
        '
        'dvgclient1
        '
        Me.dvgclient1.AllowUserToAddRows = False
        Me.dvgclient1.AllowUserToDeleteRows = False
        Me.dvgclient1.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient1.Location = New System.Drawing.Point(707, 283)
        Me.dvgclient1.Name = "dvgclient1"
        Me.dvgclient1.ReadOnly = True
        Me.dvgclient1.RowHeadersWidth = 51
        Me.dvgclient1.Size = New System.Drawing.Size(472, 266)
        Me.dvgclient1.TabIndex = 281
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(329, 257)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(141, 20)
        Me.Label3.TabIndex = 282
        Me.Label3.Text = "Client Subscription"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox1.Location = New System.Drawing.Point(144, 248)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(511, 37)
        Me.PictureBox1.TabIndex = 283
        Me.PictureBox1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(870, 257)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(164, 20)
        Me.Label5.TabIndex = 284
        Me.Label5.Text = "Available Subscription"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(707, 248)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(472, 37)
        Me.PictureBox2.TabIndex = 285
        Me.PictureBox2.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1148, 36)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 314
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Adminsub
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1330, 649)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.dvgclient1)
        Me.Controls.Add(Me.txtspeed)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtset)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmbprice)
        Me.Controls.Add(Me.cmbsub)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtsubid)
        Me.Controls.Add(Me.txtsub)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "Adminsub"
        Me.Text = "CrudSAsub"
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dvgclient1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnback As Button
    Friend WithEvents btnupdate As Button
    Friend WithEvents btnsearch As Button
    Friend WithEvents txtname As TextBox
    Friend WithEvents dvgclient As DataGridView
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents txtspeed As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtset As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbprice As TextBox
    Friend WithEvents cmbsub As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtsubid As TextBox
    Friend WithEvents txtsub As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dvgclient1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button1 As Button
End Class
