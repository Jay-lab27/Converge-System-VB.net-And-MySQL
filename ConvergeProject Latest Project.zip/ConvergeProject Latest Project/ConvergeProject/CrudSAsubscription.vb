﻿Imports MySql.Data.MySqlClient

Public Class CrudSAsubscription

    Dim count As Integer = 0
    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method
    End Sub
    Private Sub RefreshData()
        Try
            LoadToDGV("SELECT * FROM `subscription`;", dvgclient)
            LoadToDGV("SELECT * FROM `availablesubscription`;", dvgclient1)
            'if i dont want to display ID



        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub


    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try

            Dim clientInfoCount As Integer = GetRowCount("SELECT COUNT(*) FROM `subscription`")
            Dim subscriptionCount As Integer = GetRowCount("SELECT COUNT(*) FROM `availablesubscription`")

            ' Calculate total count (or handle them separately)
            Dim newCount As Integer = clientInfoCount + subscriptionCount

            If newCount <> count Then
                count = newCount

                RefreshData()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()

                ' Queries for the row count from each table

                Dim clientInfoQuery As String = "SELECT COUNT(*) FROM `subscription`;"
                Dim subscriptionQuery As String = "SELECT COUNT(*) FROM `availablesubscription`;"

                ' Execute each query and retrieve the row counts

                Dim clientInfoCount As Integer
                Dim subscriptionCount As Integer



                Using cmd As New MySqlCommand(clientInfoQuery, connection)
                    clientInfoCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                Using cmd As New MySqlCommand(subscriptionQuery, connection)
                    subscriptionCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Calculate total count (or handle them separately)
                Dim newCount As Integer = clientInfoCount + subscriptionCount

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    count = newCount
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub







    Private Sub CrudSAsubscription_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            SetupAutoRefresh()
            RefreshData()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
    ' Prevent form closure using the X button
    Private Sub CrudSAsubscription_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' Cancel the close event and show a warning
        If MsgBox("You cannot close this form using the 'X' button. Please complete the subscription details.", MsgBoxStyle.Exclamation, "Warning") = MsgBoxResult.Ok Then
            e.Cancel = True ' Cancel the closing
        End If
    End Sub



    Private Sub btncon_Click(sender As Object, e As EventArgs) Handles btncon.Click
        Try
            ' Validate required fields
            If txtclientid.Text.Trim = "" Then
                MsgBox("Enter Client ID.")
                txtclientid.Focus()
                Exit Sub
            End If

            If txtsubid.Text.Trim = "" Then
                MsgBox("Enter Subscription ID.")
                txtsubid.Focus()
                Exit Sub
            End If

            If cmbsub.Text.Trim = "" Then
                MsgBox("Select Subscription Type.")
                cmbsub.Focus()
                Exit Sub
            End If

            If cmbprice.Text.Trim = "" Then
                MsgBox("Select Subscription Price.")
                cmbprice.Focus()
                Exit Sub
            End If

            If MsgBox("Are you sure this is the subscription?", MsgBoxStyle.YesNo, "Save") = MsgBoxResult.Yes Then
                ' Prepare the query for inserting the subscription
                Dim clientId As Integer = Convert.ToInt32(txtclientid.Text) ' Foreign Key Id
                Dim subid As Integer = Convert.ToInt32(txtsubid.Text)
                Dim subscription As String = cmbsub.Text
                Dim speed As String = txtspeed.Text
                Dim setupfee As Integer = Convert.ToInt32(txtset.Text)
                Dim price As Integer = Convert.ToInt32(cmbprice.Text)

                Dim query As String = "INSERT INTO subscription(Id, SubID, Subscription, Speed, Setupfee, PriceofSubscription) " &
                               "VALUES (@clientId, @subid, @subscription, @speed, @setupfee, @price)"

                ' Open the connection from ModDB
                openConn(db_name)

                ' Prepare the MySQL command
                cmd.Connection = conn
                cmd.CommandText = query

                ' Add parameters to the query
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@clientId", clientId)
                cmd.Parameters.AddWithValue("@subid", subid)
                cmd.Parameters.AddWithValue("@subscription", subscription)
                cmd.Parameters.AddWithValue("@speed", speed)
                cmd.Parameters.AddWithValue("@setupfee", setupfee)
                cmd.Parameters.AddWithValue("@price", price)

                ' Try to execute the query to insert data into the database
                Try
                    cmd.ExecuteNonQuery()


                    Log("Saved new customer subscription" & "by: " & CurrentLoggedUser.username, "btncon_Click")
                    ' Notify the user and close the connection
                    MsgBox("Saved!")
                    Me.Hide()

                Catch ex As MySqlException
                    ' Handle foreign key constraint violation
                    If ex.Number = 1452 Then ' Error code for foreign key constraint failure
                        MsgBox("You cannot add this because this is not a valid ID", MsgBoxStyle.Critical)
                    Else
                        MsgBox(ex.Message, MsgBoxStyle.Critical)
                    End If
                End Try
            End If

            ' Refresh data in dashboards
            RefreshData()

            Dim dashboard As CrudSAsub = CType(Application.OpenForms("CrudSAsub"), CrudSAsub)
            If dashboard IsNot Nothing Then
                dashboard.RefreshDashboard()
            End If

            Dim dashboard3 As DashboardSACS = CType(Application.OpenForms("DashboardSACS"), DashboardSACS)
            If dashboard3 IsNot Nothing Then
                dashboard3.RefreshDashboard()
            End If

            Dim dashboard1 As DashboardSAP = CType(Application.OpenForms("DashboardSAP"), DashboardSAP)
            If dashboard1 IsNot Nothing Then
                dashboard1.RefreshDashboard()
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
    Private Sub dvgclient1_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgclient1.CellContentDoubleClick
        Try
            ' Ensure the clicked row index is valid
            If e.RowIndex >= 0 Then
                ' Map the values from DataGridView to the corresponding fields based on the table structure
                txtsubid.Text = dvgclient1.Rows(e.RowIndex).Cells(0).Value.ToString() ' 
                cmbsub.Text = dvgclient1.Rows(e.RowIndex).Cells(1).Value.ToString() ' SubID
                cmbprice.Text = dvgclient1.Rows(e.RowIndex).Cells(2).Value.ToString() ' Subscription
                txtspeed.Text = dvgclient1.Rows(e.RowIndex).Cells(3).Value.ToString() ' Speed
                txtset.Text = dvgclient1.Rows(e.RowIndex).Cells(4).Value.ToString() ' Setupfee


                ' Remove DateofSubscription field as it's handled by the database
                ' No need to input or set it manually


            End If
        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtsubid_TextChanged(sender As Object, e As EventArgs) Handles txtsubid.TextChanged

    End Sub

    Private Sub cmbsub_TextChanged(sender As Object, e As EventArgs) Handles cmbsub.TextChanged

    End Sub

    Private Sub cmbprice_TextChanged(sender As Object, e As EventArgs) Handles cmbprice.TextChanged

    End Sub

    Private Sub txtset_TextChanged(sender As Object, e As EventArgs) Handles txtset.TextChanged

    End Sub

    Private Sub txtspeed_TextChanged(sender As Object, e As EventArgs) Handles txtspeed.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub txtsub_Click(sender As Object, e As EventArgs) Handles txtsub.Click

    End Sub

    Private Sub txtclientid_TextChanged(sender As Object, e As EventArgs) Handles txtclientid.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SetupAutoRefresh()
        RefreshDashboard()
        RefreshData()
    End Sub
End Class