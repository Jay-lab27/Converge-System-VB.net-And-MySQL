﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar

Public Class DashboardSAP
    Dim count As Integer = 0
    Dim timer As New Timer()
    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method
    End Sub
    Private Sub RefreshData()
        Try
            LoadToDGV("SELECT * FROM `clientinfo` ORDER BY id DESC;", dvgclient)

            LoadToDGV("SELECT * FROM `subscription` ORDER BY id DESC;", dvgclient1)

            dvgclient.Columns(2).Visible = False

            LoadToDGV("SELECT * FROM `payments` ORDER BY id DESC;", dvgclient2)


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub


    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Get counts for each table separately
            Dim paymentsCount As Integer = GetRowCount("SELECT COUNT(*) FROM `payments`")
            Dim clientInfoCount As Integer = GetRowCount("SELECT COUNT(*) FROM `clientinfo`")
            Dim subscriptionCount As Integer = GetRowCount("SELECT COUNT(*) FROM `subscription`")

            ' Calculate total count (or handle them separately)
            Dim newCount As Integer = paymentsCount + clientInfoCount + subscriptionCount

            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()

                ' Queries for the row count from each table
                Dim paymentsQuery As String = "SELECT COUNT(*) FROM `payments`;"
                Dim clientInfoQuery As String = "SELECT COUNT(*) FROM `clientinfo`;"
                Dim subscriptionQuery As String = "SELECT COUNT(*) FROM `subscription`;"

                ' Execute each query and retrieve the row counts
                Dim paymentsCount As Integer
                Dim clientInfoCount As Integer
                Dim subscriptionCount As Integer

                Using cmd As New MySqlCommand(paymentsQuery, connection)
                    paymentsCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                Using cmd As New MySqlCommand(clientInfoQuery, connection)
                    clientInfoCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                Using cmd As New MySqlCommand(subscriptionQuery, connection)
                    subscriptionCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Calculate total count (or handle them separately)
                Dim newCount As Integer = paymentsCount + clientInfoCount + subscriptionCount

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    count = newCount
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub












    Private Sub btncrud_Click(sender As Object, e As EventArgs) Handles btncrud.Click
        CrudSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnci_Click(sender As Object, e As EventArgs) Handles btnci.Click
        DashboardSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnc_Click(sender As Object, e As EventArgs) Handles btnc.Click
        DashboardSACS.Show()
        Me.Hide()
    End Sub

    Private Sub btna_Click(sender As Object, e As EventArgs) Handles btna.Click
        DashboardSAAP.Show()
        Me.Hide()
    End Sub

    Private Sub btng_Click(sender As Object, e As EventArgs) Handles btng.Click
        GraphSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        ReportSA.Show()
    End Sub


    Private Sub DashboardSAP_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Me.WindowState = FormWindowState.Maximized
            SetupAutoRefresh()
            RefreshDashboard()
            RefreshData()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub txtuname_TextChanged(sender As Object, e As EventArgs) Handles txtuname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `clientinfo` WHERE CONCAT(Username, ' ', Id) LIKE '%" & txtuname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtId_TextChanged(sender As Object, e As EventArgs) Handles txtId.TextChanged
        Try
            LoadToDGV("SELECT * FROM `subscription` WHERE CONCAT(Id) LIKE '%" & txtId.Text & "%';", dvgclient1)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub



    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        ' Check if the User ID field is empty
        If txtId.Text.Trim = "" Then
            MsgBox("Enter User ID.")
            txtId.Focus()
            Exit Sub
        End If

        ' Check if the Username field is empty
        If txtuname.Text.Trim = "" Then
            MsgBox("Enter Username.")
            txtuname.Focus()
            Exit Sub
        End If

        ' Check if the First Name field is empty
        If txtfname.Text.Trim = "" Then
            MsgBox("Enter First Name.")
            txtfname.Focus()
            Exit Sub
        End If

        ' Check if the Last Name field is empty
        If txtname1.Text.Trim = "" Then
            MsgBox("Enter Last Name.")
            txtname1.Focus()
            Exit Sub
        End If

        If txtmname.Text.Trim = "" Then
            MsgBox("Enter Middle Name.")
            txtmname.Focus()
            Exit Sub
        End If

        ' Check if the Payment amount field is empty
        If cmbprice.Text.Trim = "" Then
            MsgBox("Payment amount must be selected.")
            cmbprice.Focus()
            Exit Sub
        End If

        ' Check if the Municipality is selected
        If txtmun.SelectedIndex = -1 Then
            MsgBox("Select a Municipality.")
            txtmun.Focus()
            Exit Sub
        End If

        ' Check if the Zipcode is selected
        If cmbzip.Text.Trim = "" Then
            MsgBox("Select a Zipcode.")
            cmbzip.Focus()
            Exit Sub
        End If


        ' Parse the due date, if invalid show error
        Dim dueDate As Date
        If Not Date.TryParse(txtdue.Text, dueDate) Then
            MsgBox("Invalid due date. Please enter a valid date.", MsgBoxStyle.Critical)
            txtdue.Focus()
            Exit Sub
        End If

        ' Confirm the payment action
        If MsgBox("Are you sure you want to record this payment?", MsgBoxStyle.YesNo, "Confirm Payment") = MsgBoxResult.Yes Then
            Try
                ' Parse all values from the form fields
                Dim userId As Integer = Convert.ToInt32(txtId.Text)
                Dim username As String = txtuname.Text
                Dim lastname As String = txtname1.Text
                Dim firstname As String = txtfname.Text
                Dim middlename As String = txtmname.Text
                Dim purok As String = txtpurok.Text
                Dim barangay As String = txtbar.Text
                Dim municipality As String = txtmun.Text
                Dim zipcode As String = cmbzip.Text
                Dim payment As Decimal = Convert.ToDecimal(cmbprice.Text)
                Dim lateFeeCharge As Integer = Convert.ToInt32(cmblatefee.Text)
                Dim paymentNote As String = txtreqd.Text


                ' Dim query As String = "INSERT INTO payments (UserID, Username, Lastname, Firstname, Middlename, Purok, Barangay, Municipality, Zipcode, Payment, Dateofpayment, Duedate, Latefeecharge, Paymentnote) " & _
                '                      "VALUES (@UserID, @Username, @Lastname, @Firstname, @Middlename, @Purok, @Barangay, @Municipality, @Zipcode, @Payment, CURRENT_TIMESTAMP, @Duedate, @Latefeecharge, @Paymentnote)"

                ' With this updated line, using the value from txtdatepayment for Dateofpayment
                Dim query As String = "INSERT INTO payments (UserID, Username, Lastname, Firstname, Middlename, Purok, Barangay, Municipality, Zipcode, Payment, Dateofpayment, Duedate, Latefeecharge, Paymentnote) " &
                      "VALUES (@UserID, @Username, @Lastname, @Firstname, @Middlename, @Purok, @Barangay, @Municipality, @Zipcode, @Payment, @Dateofpayment, @Duedate, @Latefeecharge, @Paymentnote)"




                Using conn As New MySqlConnection(strConnection)
                    conn.Open()
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@UserID", userId)
                        cmd.Parameters.AddWithValue("@Username", username)
                        cmd.Parameters.AddWithValue("@Lastname", lastname)
                        cmd.Parameters.AddWithValue("@Firstname", firstname)
                        cmd.Parameters.AddWithValue("@Middlename", middlename)
                        cmd.Parameters.AddWithValue("@Purok", purok)
                        cmd.Parameters.AddWithValue("@Barangay", barangay)
                        cmd.Parameters.AddWithValue("@Municipality", municipality)
                        cmd.Parameters.AddWithValue("@Zipcode", zipcode)
                        cmd.Parameters.AddWithValue("@Payment", payment)
                        cmd.Parameters.AddWithValue("@Dateofpayment", txtdatepayment.Value)
                        cmd.Parameters.AddWithValue("@Duedate", dueDate)
                        cmd.Parameters.AddWithValue("@Latefeecharge", lateFeeCharge)
                        cmd.Parameters.AddWithValue("@Paymentnote", paymentNote)

                        cmd.ExecuteNonQuery()
                    End Using
                End Using



                MsgBox("Payment successfully recorded!", MsgBoxStyle.Information)

                Log("Add an payment" & "by: " & CurrentLoggedUser.username, "btnPay")


                GraphSA.RefreshGraph()
                RefreshDashboard() ' Refresh after insertion
                Dim GRA As GraphSA1 = CType(Application.OpenForms("GraphSA1"), GraphSA1)
                If GRA IsNot Nothing Then
                    GRA.RefreshDashboard()
                End If

                Dim dashboard1 As DashboardSAP = CType(Application.OpenForms("DashboardSAP"), DashboardSAP)
                If dashboard1 IsNot Nothing Then
                    dashboard1.RefreshDashboard() ' Call the refresh method in DashboardSAP
                End If
                Dim dashboard2 As DashboardCH = CType(Application.OpenForms("DashboardCH"), DashboardCH)
                If dashboard2 IsNot Nothing Then
                    dashboard2.RefreshDashboard() ' Call the refresh method in DashboardSAP
                End If

            Catch ex As MySqlException When ex.Number = 1452 ' Error code for foreign key constraint violation
                MsgBox("You cannot send this appointment because this is not a valid ID.", MsgBoxStyle.Critical)
            Catch ex As Exception
                MsgBox($"Error: {ex.Message}", MsgBoxStyle.Critical)
            End Try
        End If
    End Sub


    Private Sub txtdatepayment_ValueChanged(sender As Object, e As EventArgs) Handles txtdatepayment.ValueChanged

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `payments` WHERE CONCAT(UserId, ' ', Username, ' ', Municipality) LIKE '%" & txtname.Text & "%';", dvgclient2)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub



    Private Sub txtmun_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtmun.SelectedIndexChanged

    End Sub

    Private Sub btnlogs_Click(sender As Object, e As EventArgs) Handles btnlogs.Click
        Logs.Show()

    End Sub

    Private Sub dvgclient_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgclient.CellContentDoubleClick
        Try
            ' Ensure the double-click is on a valid row (not the header or out of bounds)
            If e.RowIndex >= 0 Then
                Dim selectedRow As DataGridViewRow = dvgclient.Rows(e.RowIndex)


                ' Safely assign values to textboxes with null handling
                txtId.Text = If(selectedRow.Cells(0).Value IsNot Nothing, selectedRow.Cells(0).Value.ToString(), String.Empty)          ' Replace with "Id" column
                txtuname.Text = If(selectedRow.Cells(1).Value IsNot Nothing, selectedRow.Cells(1).Value.ToString(), String.Empty) ' Replace with "Username" column
                txtname1.Text = If(selectedRow.Cells(3).Value IsNot Nothing, selectedRow.Cells(3).Value.ToString(), String.Empty)  ' Replace with "Lastname" column
                txtfname.Text = If(selectedRow.Cells(4).Value IsNot Nothing, selectedRow.Cells(4).Value.ToString(), String.Empty)  ' Replace with "Firstname" column
                txtmname.Text = If(selectedRow.Cells(5).Value IsNot Nothing, selectedRow.Cells(5).Value.ToString(), String.Empty)  ' Replace with "Middlename" column
                txtpurok.Text = If(selectedRow.Cells(9).Value IsNot Nothing, selectedRow.Cells(9).Value.ToString(), String.Empty)     ' Replace with "Purok" column
                txtbar.Text = If(selectedRow.Cells(10).Value IsNot Nothing, selectedRow.Cells(10).Value.ToString(), String.Empty) ' Barangay column
                txtmun.Text = If(selectedRow.Cells(11).Value IsNot Nothing, selectedRow.Cells(11).Value.ToString(), String.Empty) ' Municipality column
                cmbzip.Text = If(selectedRow.Cells(12).Value IsNot Nothing, selectedRow.Cells(12).Value.ToString(), String.Empty) ' Zipcode column
            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred while processing the selected row: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtpurok_TextChanged(sender As Object, e As EventArgs) Handles txtpurok.TextChanged

    End Sub

    Private Sub Label18_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnsubo_Click(sender As Object, e As EventArgs) Handles btnsubo.Click
        DashboardSAsuboffer.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FeedbackSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RefreshData()
        GraphSA.RefreshGraph()
        SetupAutoRefresh()
        RefreshDashboard()
    End Sub
End Class