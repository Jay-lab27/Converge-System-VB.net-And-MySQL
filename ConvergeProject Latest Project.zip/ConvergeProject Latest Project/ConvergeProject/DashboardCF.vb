﻿Imports MySql.Data.MySqlClient

Public Class DashboardCF


    Private Sub btnsend_Click(sender As Object, e As EventArgs) Handles btnsend.Click
        Try
            ' Validate required fields
            If txtId.Text.Trim = "" Then
                MsgBox("Enter Id.")
                txtId.Focus()
                Exit Sub
            End If
            ' Validate required fields
            If txtuname.Text.Trim = "" Then
                MsgBox("Enter Username.")
                txtuname.Focus()
                Exit Sub
            End If
            If txtname1.Text.Trim = "" Then
                MsgBox("Enter Lastname.")
                txtname1.Focus()
                Exit Sub
            End If
            If txtfname.Text.Trim = "" Then
                MsgBox("Enter Firstname.")
                txtfname.Focus()
                Exit Sub
            End If
            If txtmname.Text.Trim = "" Then
                MsgBox("Enter Middlename.")
                txtmname.Focus()
                Exit Sub
            End If
            If txtpurok.Text.Trim = "" Then
                MsgBox("Enter Purok.")
                txtpurok.Focus()
                Exit Sub
            End If
            If txtbar.Text.Trim = "" Then
                MsgBox("Enter Barangay.")
                txtbar.Focus()
                Exit Sub
            End If
            If txtmun.Text.Trim = "" Then
                MsgBox("Enter Municipality.")
                txtmun.Focus()
                Exit Sub
            End If
            If txtnum.Text.Trim = "" Then
                MsgBox("Enter Contact Number.")
                txtnum.Focus()
                Exit Sub
            End If
            If txtgmail.Text.Trim = "" Then
                MsgBox("Enter Gmail.")
                txtgmail.Focus()
                Exit Sub
            End If
            If cmbrate.Text.Trim = "" Then
                MsgBox("Select Service Rating.")
                cmbrate.Focus()
                Exit Sub
            End If
            If cmbcat.Text.Trim = "" Then
                MsgBox("Select Feedback Category.")
                cmbcat.Focus()
                Exit Sub
            End If
            If txtdetail.Text.Trim = "" Then
                MsgBox("Enter Detailed Feedback.")
                txtdetail.Focus()
                Exit Sub
            End If

            ' Check if the UserID exists in the client_info table
            Dim userIdExists As Boolean = False

            Dim query As String = "SELECT COUNT(*) FROM clientinfo WHERE Id = @UserID"
            Using cmd As New MySqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", txtId.Text.Trim)
                userIdExists = Convert.ToInt32(cmd.ExecuteScalar()) > 0
            End Using


            If Not userIdExists Then
                MsgBox("You cannot send this appointment because this is not a valid ID.")
                Exit Sub
            End If

            ' Confirm save
            If MsgBox("Are you sure you want to send this feedback?", MsgBoxStyle.YesNo, "send Feedback") = MsgBoxResult.Yes Then
                readQuery(String.Format("INSERT INTO feedback (UserId, Username, Lastname, Firstname, Middlename, Purok, Barangay, Municipality, ContactNo, Gmail, Servicerating, Feedbackcategory, Detailedfeedback) " &
                    "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}')",
                    txtId.Text.Trim, txtuname.Text.Trim, txtname1.Text.Trim, txtfname.Text.Trim, txtmname.Text.Trim,
                    txtpurok.Text.Trim, txtbar.Text.Trim, txtmun.Text.Trim, txtnum.Text.Trim, txtgmail.Text.Trim,
                    cmbrate.Text.Trim, cmbcat.Text.Trim, txtdetail.Text.Trim))

                readQuery(query)
                MsgBox("Feedback saved successfully!")

            End If
            Dim dashboard As FeedbackSA = CType(Application.OpenForms("FeedbackSA"), FeedbackSA)
            If dashboard IsNot Nothing Then
                dashboard.RefreshDashboard() ' Call the refresh method
            End If

            txtId.Clear()
            txtuname.Clear()
            txtname1.Clear()
            txtfname.Clear()
            txtmname.Clear()
            txtpurok.Clear()
            txtbar.Clear()
            txtmun.SelectedIndex = -1
            txtnum.Clear()
            txtgmail.Clear()
            txtdetail.Clear()
            cmbrate.SelectedIndex = -1
            cmbcat.SelectedIndex = -1
            txtdetail.Clear()

        Catch ex As MySqlException When ex.Number = 1452 ' Error code for foreign key constraint violation
            MsgBox("You cannot send this appointment because this is not a valid ID.", MsgBoxStyle.Critical)
        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub DashboardCF_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateConnectionString()
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub btnhistory_Click(sender As Object, e As EventArgs) Handles btnhistory.Click
        DashboardCH.Show()
        Me.Hide()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub btnappoint_Click(sender As Object, e As EventArgs) Handles btnappoint.Click
        DashboardC.Show()

    End Sub
End Class