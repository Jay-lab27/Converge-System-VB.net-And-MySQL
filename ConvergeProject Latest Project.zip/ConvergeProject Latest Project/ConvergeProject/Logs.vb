﻿Imports MySql.Data.MySqlClient

Public Class Logs

    Dim count As Integer = 0
    Dim timer As New Timer()


    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 10000 ' Refresh every 20 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `logs`;dvgclient")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `logs`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method
    End Sub
    Private Sub RefreshData()
        Try
            LoadToDGV("SELECT * FROM `logs` ORDER BY id DESC;", dvgclient)



            dvgclient.Columns(2).Visible = False

            GraphSA.RefreshGraph()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub








    Private Sub txtname_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Logs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateConnectionString()
        Try
            SetupAutoRefresh()
            RefreshDashboard()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dvgclient_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgclient.CellContentClick

    End Sub

    Private Sub txtname_TextChanged_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SetupAutoRefresh()
        RefreshDashboard()
        RefreshData()
    End Sub
End Class