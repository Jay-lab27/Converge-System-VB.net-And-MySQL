﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btncon = New System.Windows.Forms.Button()
        Me.txtsub = New System.Windows.Forms.Label()
        Me.txtreportn = New System.Windows.Forms.TextBox()
        Me.cmbreport = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.daterev = New System.Windows.Forms.DateTimePicker()
        Me.dvgclient2 = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.dvgclient2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(333, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(141, 31)
        Me.Label4.TabIndex = 166
        Me.Label4.Text = "R E P O R T"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Tai Le", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(125, 103)
        Me.Label5.Margin = New System.Windows.Forms.Padding(0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(276, 45)
        Me.Label5.TabIndex = 165
        Me.Label5.Text = "C O N V E R G E"
        '
        'btncon
        '
        Me.btncon.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btncon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncon.Location = New System.Drawing.Point(145, 389)
        Me.btncon.Name = "btncon"
        Me.btncon.Size = New System.Drawing.Size(245, 33)
        Me.btncon.TabIndex = 163
        Me.btncon.Text = "Export"
        Me.btncon.UseVisualStyleBackColor = False
        '
        'txtsub
        '
        Me.txtsub.AutoSize = True
        Me.txtsub.BackColor = System.Drawing.SystemColors.Control
        Me.txtsub.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsub.Location = New System.Drawing.Point(141, 255)
        Me.txtsub.Name = "txtsub"
        Me.txtsub.Size = New System.Drawing.Size(105, 20)
        Me.txtsub.TabIndex = 158
        Me.txtsub.Text = "Export Name:"
        '
        'txtreportn
        '
        Me.txtreportn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtreportn.Location = New System.Drawing.Point(145, 278)
        Me.txtreportn.Name = "txtreportn"
        Me.txtreportn.Size = New System.Drawing.Size(245, 26)
        Me.txtreportn.TabIndex = 168
        '
        'cmbreport
        '
        Me.cmbreport.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem
        Me.cmbreport.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbreport.FormattingEnabled = True
        Me.cmbreport.Items.AddRange(New Object() {"Client Info Record", "Client Subscription Record", "Payment Record", "Monthly Revenue Record", "Feedback Record", "Appointment Record"})
        Me.cmbreport.Location = New System.Drawing.Point(145, 336)
        Me.cmbreport.Name = "cmbreport"
        Me.cmbreport.Size = New System.Drawing.Size(245, 28)
        Me.cmbreport.TabIndex = 169
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(141, 313)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 20)
        Me.Label1.TabIndex = 170
        Me.Label1.Text = "Report:"
        '
        'daterev
        '
        Me.daterev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.daterev.Location = New System.Drawing.Point(395, 278)
        Me.daterev.Margin = New System.Windows.Forms.Padding(2)
        Me.daterev.Name = "daterev"
        Me.daterev.Size = New System.Drawing.Size(28, 26)
        Me.daterev.TabIndex = 226
        '
        'dvgclient2
        '
        Me.dvgclient2.AllowUserToAddRows = False
        Me.dvgclient2.AllowUserToDeleteRows = False
        Me.dvgclient2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dvgclient2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient2.Location = New System.Drawing.Point(111, 231)
        Me.dvgclient2.Name = "dvgclient2"
        Me.dvgclient2.ReadOnly = True
        Me.dvgclient2.Size = New System.Drawing.Size(337, 223)
        Me.dvgclient2.TabIndex = 238
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(228, 212)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(117, 16)
        Me.Label6.TabIndex = 236
        Me.Label6.Text = "Records Report"
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox6.Location = New System.Drawing.Point(111, 202)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(337, 38)
        Me.PictureBox6.TabIndex = 237
        Me.PictureBox6.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ConvergeProject.My.Resources.Resources.f
        Me.PictureBox1.Location = New System.Drawing.Point(12, 30)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(293, 166)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 164
        Me.PictureBox1.TabStop = False
        '
        'AdminReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(526, 495)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.daterev)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbreport)
        Me.Controls.Add(Me.txtreportn)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btncon)
        Me.Controls.Add(Me.txtsub)
        Me.Controls.Add(Me.dvgclient2)
        Me.Name = "AdminReport"
        Me.Text = "ReportSA"
        CType(Me.dvgclient2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btncon As Button
    Friend WithEvents txtsub As Label
    Friend WithEvents txtreportn As TextBox
    Friend WithEvents cmbreport As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents daterev As DateTimePicker
    Friend WithEvents dvgclient2 As DataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox6 As PictureBox
End Class
