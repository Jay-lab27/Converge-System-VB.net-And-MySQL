﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DashboardSAsuboffer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnlogs = New System.Windows.Forms.Button()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.dvgclient = New System.Windows.Forms.DataGridView()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btng = New System.Windows.Forms.Button()
        Me.btnd = New System.Windows.Forms.Button()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.textfee = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtprice = New System.Windows.Forms.TextBox()
        Me.txtsname = New System.Windows.Forms.TextBox()
        Me.txtspeed = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtsubname = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(55, 358)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 189
        Me.Button1.Text = "Subscription Offer"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnlogs
        '
        Me.btnlogs.Location = New System.Drawing.Point(55, 299)
        Me.btnlogs.Name = "btnlogs"
        Me.btnlogs.Size = New System.Drawing.Size(83, 34)
        Me.btnlogs.TabIndex = 188
        Me.btnlogs.Text = "Logs"
        Me.btnlogs.UseVisualStyleBackColor = True
        '
        'lblcount
        '
        Me.lblcount.AutoSize = True
        Me.lblcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(321, 603)
        Me.lblcount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(57, 20)
        Me.lblcount.TabIndex = 182
        Me.lblcount.Text = "Label2"
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(989, 119)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(236, 26)
        Me.txtname.TabIndex = 177
        '
        'dvgclient
        '
        Me.dvgclient.AllowUserToAddRows = False
        Me.dvgclient.AllowUserToDeleteRows = False
        Me.dvgclient.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient.GridColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.Location = New System.Drawing.Point(325, 277)
        Me.dvgclient.Margin = New System.Windows.Forms.Padding(1)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.ReadOnly = True
        Me.dvgclient.Size = New System.Drawing.Size(900, 325)
        Me.dvgclient.TabIndex = 176
        '
        'btnr
        '
        Me.btnr.Location = New System.Drawing.Point(55, 244)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(83, 34)
        Me.btnr.TabIndex = 175
        Me.btnr.Text = "Report"
        Me.btnr.UseVisualStyleBackColor = True
        '
        'btng
        '
        Me.btng.Location = New System.Drawing.Point(55, 187)
        Me.btng.Name = "btng"
        Me.btng.Size = New System.Drawing.Size(83, 34)
        Me.btng.TabIndex = 174
        Me.btng.Text = "Graph"
        Me.btng.UseVisualStyleBackColor = True
        '
        'btnd
        '
        Me.btnd.Location = New System.Drawing.Point(55, 133)
        Me.btnd.Name = "btnd"
        Me.btnd.Size = New System.Drawing.Size(83, 34)
        Me.btnd.TabIndex = 172
        Me.btnd.Text = "Dashboard"
        Me.btnd.UseVisualStyleBackColor = True
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(55, 637)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 171
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(51, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 20)
        Me.Label1.TabIndex = 170
        Me.Label1.Text = "Super Admin"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.Location = New System.Drawing.Point(268, 91)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(1)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(996, 580)
        Me.DataGridView1.TabIndex = 184
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(961, 94)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(83, 33)
        Me.btnsearch.TabIndex = 178
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(368, 71)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 25)
        Me.Label4.TabIndex = 186
        Me.Label4.Text = "Subscription Offer"
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Crimson
        Me.btndelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btndelete.Location = New System.Drawing.Point(1150, 212)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(75, 27)
        Me.btndelete.TabIndex = 193
        Me.btndelete.Text = "Delete"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(884, 211)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 29)
        Me.btnadd.TabIndex = 192
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'btnupdate
        '
        Me.btnupdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(977, 212)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 27)
        Me.btnupdate.TabIndex = 191
        Me.btnupdate.Text = "Update"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'textfee
        '
        Me.textfee.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textfee.Location = New System.Drawing.Point(624, 212)
        Me.textfee.Name = "textfee"
        Me.textfee.Size = New System.Drawing.Size(215, 26)
        Me.textfee.TabIndex = 201
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(620, 189)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 20)
        Me.Label13.TabIndex = 200
        Me.Label13.Text = "Set up fee:"
        '
        'txtprice
        '
        Me.txtprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtprice.Location = New System.Drawing.Point(352, 212)
        Me.txtprice.Name = "txtprice"
        Me.txtprice.Size = New System.Drawing.Size(215, 26)
        Me.txtprice.TabIndex = 199
        '
        'txtsname
        '
        Me.txtsname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsname.Location = New System.Drawing.Point(352, 151)
        Me.txtsname.Name = "txtsname"
        Me.txtsname.Size = New System.Drawing.Size(215, 26)
        Me.txtsname.TabIndex = 198
        '
        'txtspeed
        '
        Me.txtspeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtspeed.Location = New System.Drawing.Point(624, 147)
        Me.txtspeed.Name = "txtspeed"
        Me.txtspeed.Size = New System.Drawing.Size(215, 26)
        Me.txtspeed.TabIndex = 197
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(348, 189)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 20)
        Me.Label2.TabIndex = 196
        Me.Label2.Text = "Price Of Subscription"
        '
        'txtsubname
        '
        Me.txtsubname.AutoSize = True
        Me.txtsubname.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.txtsubname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsubname.Location = New System.Drawing.Point(348, 128)
        Me.txtsubname.Name = "txtsubname"
        Me.txtsubname.Size = New System.Drawing.Size(147, 20)
        Me.txtsubname.TabIndex = 195
        Me.txtsubname.Text = "Subscription Name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(620, 124)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(120, 20)
        Me.Label5.TabIndex = 194
        Me.Label5.Text = "Internet Speed:"
        '
        'btnclear
        '
        Me.btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.Location = New System.Drawing.Point(1065, 213)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 27)
        Me.btnclear.TabIndex = 202
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox4.Location = New System.Drawing.Point(325, 61)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(267, 48)
        Me.PictureBox4.TabIndex = 187
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.ConvergeProject.My.Resources.Resources.search_icon_png_21
        Me.PictureBox3.Location = New System.Drawing.Point(960, 119)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 185
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(32, 48)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 169
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(0, -2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 707)
        Me.PictureBox2.TabIndex = 168
        Me.PictureBox2.TabStop = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(55, 421)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(83, 34)
        Me.Button3.TabIndex = 203
        Me.Button3.Text = "Feedback "
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1162, 47)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 34)
        Me.Button2.TabIndex = 265
        Me.Button2.Text = "Refresh"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'DashboardSAsuboffer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1314, 706)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.textfee)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtprice)
        Me.Controls.Add(Me.txtsname)
        Me.Controls.Add(Me.txtspeed)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtsubname)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnlogs)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btng)
        Me.Controls.Add(Me.btnd)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "DashboardSAsuboffer"
        Me.Text = "DashboardSAsuboffer"
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents btnlogs As Button
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents lblcount As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents dvgclient As DataGridView
    Friend WithEvents btnr As Button
    Friend WithEvents btng As Button
    Friend WithEvents btnd As Button
    Friend WithEvents btnlogout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnsearch As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents btndelete As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents btnupdate As Button
    Friend WithEvents textfee As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtprice As TextBox
    Friend WithEvents txtsname As TextBox
    Friend WithEvents txtspeed As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtsubname As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnclear As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
End Class
