﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btng = New System.Windows.Forms.Button()
        Me.btna = New System.Windows.Forms.Button()
        Me.btnd = New System.Windows.Forms.Button()
        Me.dvgclient = New System.Windows.Forms.DataGridView()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.btnci = New System.Windows.Forms.Button()
        Me.btnsc = New System.Windows.Forms.Button()
        Me.btnp = New System.Windows.Forms.Button()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.btncrud = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnsubo = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 20)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Admin"
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(54, 636)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 24
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'btnr
        '
        Me.btnr.Location = New System.Drawing.Point(54, 243)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(83, 34)
        Me.btnr.TabIndex = 32
        Me.btnr.Text = "Report"
        Me.btnr.UseVisualStyleBackColor = True
        '
        'btng
        '
        Me.btng.Location = New System.Drawing.Point(54, 186)
        Me.btng.Name = "btng"
        Me.btng.Size = New System.Drawing.Size(83, 34)
        Me.btng.TabIndex = 31
        Me.btng.Text = "Graph"
        Me.btng.UseVisualStyleBackColor = True
        '
        'btna
        '
        Me.btna.Location = New System.Drawing.Point(566, 129)
        Me.btna.Name = "btna"
        Me.btna.Size = New System.Drawing.Size(83, 33)
        Me.btna.TabIndex = 30
        Me.btna.Text = "Appointment"
        Me.btna.UseVisualStyleBackColor = True
        '
        'btnd
        '
        Me.btnd.Location = New System.Drawing.Point(54, 132)
        Me.btnd.Name = "btnd"
        Me.btnd.Size = New System.Drawing.Size(83, 34)
        Me.btnd.TabIndex = 29
        Me.btnd.Text = "Dashboard"
        Me.btnd.UseVisualStyleBackColor = True
        '
        'dvgclient
        '
        Me.dvgclient.AllowUserToAddRows = False
        Me.dvgclient.AllowUserToDeleteRows = False
        Me.dvgclient.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient.GridColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.Location = New System.Drawing.Point(307, 182)
        Me.dvgclient.Margin = New System.Windows.Forms.Padding(1)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.ReadOnly = True
        Me.dvgclient.Size = New System.Drawing.Size(917, 419)
        Me.dvgclient.TabIndex = 33
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(1032, 132)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(192, 26)
        Me.txtname.TabIndex = 34
        '
        'btnci
        '
        Me.btnci.Location = New System.Drawing.Point(308, 131)
        Me.btnci.Name = "btnci"
        Me.btnci.Size = New System.Drawing.Size(105, 33)
        Me.btnci.TabIndex = 36
        Me.btnci.Text = "Client Information"
        Me.btnci.UseVisualStyleBackColor = True
        '
        'btnsc
        '
        Me.btnsc.Location = New System.Drawing.Point(434, 129)
        Me.btnsc.Name = "btnsc"
        Me.btnsc.Size = New System.Drawing.Size(103, 33)
        Me.btnsc.TabIndex = 37
        Me.btnsc.Text = "Client Subscription"
        Me.btnsc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnsc.UseVisualStyleBackColor = True
        '
        'btnp
        '
        Me.btnp.Location = New System.Drawing.Point(679, 129)
        Me.btnp.Name = "btnp"
        Me.btnp.Size = New System.Drawing.Size(74, 33)
        Me.btnp.TabIndex = 38
        Me.btnp.Text = "Payment"
        Me.btnp.UseVisualStyleBackColor = True
        '
        'lblcount
        '
        Me.lblcount.AutoSize = True
        Me.lblcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(303, 602)
        Me.lblcount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(57, 20)
        Me.lblcount.TabIndex = 58
        Me.lblcount.Text = "Label2"
        '
        'btncrud
        '
        Me.btncrud.Location = New System.Drawing.Point(785, 129)
        Me.btncrud.Name = "btncrud"
        Me.btncrud.Size = New System.Drawing.Size(105, 33)
        Me.btncrud.TabIndex = 59
        Me.btncrud.Text = "CRUD"
        Me.btncrud.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.Location = New System.Drawing.Point(267, 90)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(1)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(996, 580)
        Me.DataGridView1.TabIndex = 60
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(960, 93)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(83, 33)
        Me.btnsearch.TabIndex = 35
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(396, 71)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 25)
        Me.Label4.TabIndex = 163
        Me.Label4.Text = "Dashboard"
        '
        'btnsubo
        '
        Me.btnsubo.Location = New System.Drawing.Point(54, 299)
        Me.btnsubo.Name = "btnsubo"
        Me.btnsubo.Size = New System.Drawing.Size(83, 34)
        Me.btnsubo.TabIndex = 166
        Me.btnsubo.Text = "Subscription Offer"
        Me.btnsubo.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(54, 356)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 34)
        Me.Button2.TabIndex = 167
        Me.Button2.Text = "Feedback "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox4.Location = New System.Drawing.Point(324, 60)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(267, 48)
        Me.PictureBox4.TabIndex = 164
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.ConvergeProject.My.Resources.Resources.search_icon_png_21
        Me.PictureBox3.Location = New System.Drawing.Point(1006, 132)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 89
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(31, 47)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(-1, -3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 707)
        Me.PictureBox2.TabIndex = 20
        Me.PictureBox2.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1163, 46)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 312
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'AdminDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1315, 700)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnsubo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.btncrud)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.btnp)
        Me.Controls.Add(Me.btnsc)
        Me.Controls.Add(Me.btnci)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btng)
        Me.Controls.Add(Me.btna)
        Me.Controls.Add(Me.btnd)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "AdminDashboard"
        Me.Text = "      "
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnlogout As Button
    Friend WithEvents btnr As Button
    Friend WithEvents btng As Button
    Friend WithEvents btna As Button
    Friend WithEvents btnd As Button
    Friend WithEvents dvgclient As DataGridView
    Friend WithEvents txtname As TextBox
    Friend WithEvents btnci As Button
    Friend WithEvents btnsc As Button
    Friend WithEvents btnp As Button
    Friend WithEvents lblcount As Label
    Friend WithEvents btncrud As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnsearch As Button
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnsubo As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
