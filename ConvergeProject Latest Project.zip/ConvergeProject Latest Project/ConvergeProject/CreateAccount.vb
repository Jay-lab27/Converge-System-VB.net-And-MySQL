﻿Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient

Public Class CreateAccount
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub CreateAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateConnectionString()
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub txtuname_TextChanged(sender As Object, e As EventArgs) Handles txtuname.TextChanged

    End Sub

    Private Sub txtpass_TextChanged(sender As Object, e As EventArgs) Handles txtpass.TextChanged

    End Sub

    Private Sub txtconpass_TextChanged(sender As Object, e As EventArgs) Handles txtconpass.TextChanged

    End Sub

    Private Sub txtposition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtposition.SelectedIndexChanged

    End Sub

    Private Sub txtmunicipal_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtmun.SelectedIndexChanged

    End Sub
    ' Function to validate input fields and passwords
    Private Function ValidateInputs() As Boolean
        ' Validate Username
        If String.IsNullOrWhiteSpace(txtuname.Text) Then
            MessageBox.Show("Please enter a username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtuname.Focus()
            Return False
        End If

        ' Validate Password
        If String.IsNullOrWhiteSpace(txtpass.Text) Then
            MessageBox.Show("Please enter a password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtpass.Focus()
            Return False
        End If

        ' Ensure password is at least 6 characters long
        If txtpass.Text.Length < 6 Then
            MessageBox.Show("Password must be at least 6 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtpass.Focus()
            Return False
        End If

        ' Validate Confirmation Password
        If String.IsNullOrWhiteSpace(txtconpass.Text) Then
            MessageBox.Show("Please confirm your password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtconpass.Focus()
            Return False
        End If

        ' Ensure passwords match
        If txtpass.Text <> txtconpass.Text Then
            MessageBox.Show("Passwords do not match. Please re-enter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtconpass.Focus()
            Return False
        End If

        ' Validate Position
        If String.IsNullOrWhiteSpace(txtposition.Text) Then
            MessageBox.Show("Please select a position.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtposition.Focus()
            Return False
        End If

        ' Validate Last Name
        If String.IsNullOrWhiteSpace(txtname1.Text) Then
            MessageBox.Show("Please enter a last name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtname1.Focus()
            Return False
        End If

        ' Validate First Name
        If String.IsNullOrWhiteSpace(txtfname.Text) Then
            MessageBox.Show("Please enter a first name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtfname.Focus()
            Return False
        End If

        ' Validate Middle Name
        If String.IsNullOrWhiteSpace(txtmname.Text) Then
            MessageBox.Show("Please enter a middle name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtmname.Focus()
            Return False
        End If

        ' Validate Sex
        If String.IsNullOrWhiteSpace(cmbsex.Text) Then
            MessageBox.Show("Please select a gender.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cmbsex.Focus()
            Return False
        End If

        ' Validate Birthdate
        If Bdate.Value >= Date.Now Then
            MessageBox.Show("Please enter a valid birthdate.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Bdate.Focus()
            Return False
        End If

        ' Validate Purok
        If String.IsNullOrWhiteSpace(txtpurok.Text) Then
            MessageBox.Show("Please enter a purok.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtpurok.Focus()
            Return False
        End If

        ' Validate Barangay
        If String.IsNullOrWhiteSpace(txtbar.Text) Then
            MessageBox.Show("Please enter a barangay.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtbar.Focus()
            Return False
        End If

        ' Validate Municipality
        If String.IsNullOrWhiteSpace(txtmun.Text) Then
            MessageBox.Show("Please select a municipality.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtmun.Focus()
            Return False
        End If

        ' Validate Zip Code
        If String.IsNullOrWhiteSpace(cmbzip.Text) OrElse Not IsNumeric(cmbzip.Text) Then
            MessageBox.Show("Please enter a valid zip code.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cmbzip.Focus()
            Return False
        End If

        ' Validate Contact Number
        If String.IsNullOrWhiteSpace(txtnum.Text) OrElse Not IsNumeric(txtnum.Text) Then
            MessageBox.Show("Please enter a valid contact number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtnum.Focus()
            Return False
        End If

        ' Validate Gmail
        If String.IsNullOrWhiteSpace(txtgmail.Text) Then
            MessageBox.Show("Please enter an email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtgmail.Focus()
            Return False
        End If

        If Not Regex.IsMatch(txtgmail.Text, "^[^@\s]+@[^@\s]+\.[^@\s]+$") Then
            MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtgmail.Focus()
            Return False
        End If

        Return True
    End Function


    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click
        ' Validate all inputs before proceeding
        If Not ValidateInputs() Then
            Return
        End If

        Try
            UpdateConnectionString()
            Dim encryptedPassword As String = Encrypt(txtpass.Text)

            Using conn As New MySqlConnection(strConnection)
                conn.Open()

                Dim checkQuery As String = "SELECT COUNT(*) FROM `admin` WHERE Username = @username"
                Using checkCmd As New MySqlCommand(checkQuery, conn)
                    checkCmd.Parameters.AddWithValue("@username", txtuname.Text)
                    Dim count As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())
                    If count > 0 Then
                        MessageBox.Show("Username already exists. Please choose a different username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtuname.Focus()
                        Return
                    End If
                End Using

                Dim query As String = "INSERT INTO `admin` (Username, Password, Position, Lastname, Firstname, Middlename, Sex, Birthdate, Purok, Barangay, Municipality, Zipcode, ContactNo, Gmail) 
                                       VALUES (@username, @password, @position, @lastname, @firstname, @middlename, @sex, @birthdate, @purok, @barangay, @municipality, @zipcode, @contactno, @gmail)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@username", txtuname.Text)
                    cmd.Parameters.AddWithValue("@password", encryptedPassword)
                    cmd.Parameters.AddWithValue("@position", txtposition.Text)
                    cmd.Parameters.AddWithValue("@lastname", txtname1.Text)
                    cmd.Parameters.AddWithValue("@firstname", txtfname.Text)
                    cmd.Parameters.AddWithValue("@middlename", txtmname.Text)
                    cmd.Parameters.AddWithValue("@sex", cmbsex.Text)
                    cmd.Parameters.AddWithValue("@birthdate", Bdate.Value.ToString("yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@purok", txtpurok.Text)
                    cmd.Parameters.AddWithValue("@barangay", txtbar.Text)
                    cmd.Parameters.AddWithValue("@municipality", txtmun.Text)
                    cmd.Parameters.AddWithValue("@zipcode", cmbzip.Text)
                    cmd.Parameters.AddWithValue("@contactno", txtnum.Text)
                    cmd.Parameters.AddWithValue("@gmail", txtgmail.Text)

                    cmd.ExecuteNonQuery()
                End Using

                conn.Close()
            End Using

            MessageBox.Show("Account created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
        Catch ex As MySqlException
            MessageBox.Show("An error occurred while creating the account: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearFields()
        txtuname.Clear()
        txtpass.Clear()
        txtconpass.Clear()
        txtposition.SelectedIndex = -1
        txtmun.SelectedIndex = -1
        txtname1.Clear()
        txtfname.Clear()
        txtmname.Clear()
        cmbsex.SelectedIndex = -1
        Bdate.Value = DateTime.Now
        txtpurok.Clear()
        txtbar.Clear()
        cmbzip.SelectedIndex = -1
        txtnum.Clear()
        txtgmail.Clear()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub cmbsex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbsex.SelectedIndexChanged

    End Sub

    Private Sub Bdate_ValueChanged(sender As Object, e As EventArgs) Handles Bdate.ValueChanged

    End Sub

    Private Sub txtpurok_TextChanged(sender As Object, e As EventArgs) Handles txtpurok.TextChanged

    End Sub

    Private Sub txtbar_TextChanged(sender As Object, e As EventArgs) Handles txtbar.TextChanged

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs)

    End Sub
End Class