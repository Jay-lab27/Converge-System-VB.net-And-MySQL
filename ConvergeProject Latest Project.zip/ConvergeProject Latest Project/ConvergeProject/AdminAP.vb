﻿Imports MySql.Data.MySqlClient

Public Class AdminAP
    Dim count As Integer = 0
    Dim timer As New Timer()

    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `appointment`;")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `appointment`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Public Sub RefreshDashboard()
        RefreshData()

    End Sub


    Private Sub RefreshData()
        Try

            Dim selectedDate As Date = dptdatepick.Value

            Dim formattedDate As String = selectedDate.ToString("yyyy-MM-dd")


            Dim query As String = "SELECT * FROM `appointment` WHERE DATE(AppointmentDate) = '" & formattedDate & "';"


            count = LoadToDGV(query, dvgclient)

            lblcount.Text = "Total Appointment: " & count

        Catch ex As Exception
            ' Display any errors encountered during the process
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub AdminAP_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Me.WindowState = FormWindowState.Maximized
            RefreshData()
            SetupAutoRefresh()
            RefreshDashboard()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `appointment` WHERE CONCAT(Username, ' ',Firstname, ' ', Municipality) LIKE '%" & txtname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dptdatepick_ValueChanged(sender As Object, e As EventArgs) Handles dptdatepick.ValueChanged
        Try

            Dim selectedDate As Date = dptdatepick.Value

            Dim formattedDate As String = selectedDate.ToString("yyyy-MM-dd")

            Dim query As String = "SELECT * FROM `appointment` WHERE DATE(AppointmentDate) = '" & formattedDate & "';"


            count = LoadToDGV(query, dvgclient)


            lblcount.Text = "Total Appointment: " & count

        Catch ex As Exception
            ' Display any errors encountered during the process
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnci_Click(sender As Object, e As EventArgs) Handles btnci.Click
        AdminDashboard.Show()
        Me.Hide()
    End Sub

    Private Sub btnc_Click(sender As Object, e As EventArgs) Handles btnc.Click
        AdminCS.Show()
        Me.Hide()
    End Sub

    Private Sub btnp_Click(sender As Object, e As EventArgs) Handles btnp.Click
        AdminP.Show()
        Me.Hide()
    End Sub

    Private Sub btncrud_Click(sender As Object, e As EventArgs) Handles btncrud.Click
        AdminCrud.Show()
        Me.Hide()
    End Sub

    Private Sub btnd_Click(sender As Object, e As EventArgs) Handles btnd.Click

    End Sub

    Private Sub btng_Click(sender As Object, e As EventArgs) Handles btng.Click
        AdminGraph.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        AdminReport.Show()

    End Sub

    Private Sub btnsubo_Click(sender As Object, e As EventArgs) Handles btnsubo.Click
        Adminsuboffer.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AdminFeedback.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RefreshDashboard()
        RefreshData()
    End Sub
End Class