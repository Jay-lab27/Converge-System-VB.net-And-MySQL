﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar
Imports MySql.Data.MySqlClient

Public Class DashboardSACS

    Dim count As Integer = 0
    Dim timer As New Timer()


    Public Sub RefreshDashboard()
        RefreshData() ' Call the existing RefreshData method


        SetupAutoRefresh()
    End Sub
    Private Sub RefreshData()
        Try
            count = LoadToDGV("SELECT * FROM `subscription`;", dvgclient)

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub



    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `subscription`;")
            If newCount <> count Then
                count = newCount
                RefreshData() ' Refresh the DataGridView if there are changes
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `subscription`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshData()
                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub













    Private Sub btnci_Click(sender As Object, e As EventArgs) Handles btnci.Click
        DashboardSA.Show()
        Me.Hide()

    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub DashboardSACS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateConnectionString()
        Me.WindowState = FormWindowState.Maximized
        Try
            RefreshData()
            RefreshDashboard()
            SetupAutoRefresh()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try


    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
        Try
            LoadToDGV("SELECT * FROM `subscription` WHERE CONCAT(Id, ' ',Subscription) LIKE '%" & txtname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            LoadToDGV("SELECT * FROM `subscription` WHERE CONCAT(Id, ' ',Subscription) LIKE '%" & txtname.Text & "%';", dvgclient)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btncrud_Click(sender As Object, e As EventArgs) Handles btncrud.Click
        CrudSA.Show()
        Me.Hide()

    End Sub

    Private Sub btna_Click(sender As Object, e As EventArgs) Handles btna.Click
        DashboardSAAP.Show()
        Me.Hide()

    End Sub

    Private Sub btnp_Click(sender As Object, e As EventArgs) Handles btnp.Click
        DashboardSAP.Show()
        Me.Hide()
    End Sub


    Private Sub btng_Click(sender As Object, e As EventArgs) Handles btng.Click
        GraphSA.Show()
        Me.Hide()
    End Sub

    Private Sub btnr_Click(sender As Object, e As EventArgs) Handles btnr.Click
        ReportSA.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) 
        CrudSAsub.Show()
        Me.Hide()
    End Sub

    Private Sub btnlogs_Click(sender As Object, e As EventArgs) Handles btnlogs.Click
        Logs.Show()

    End Sub

    Private Sub btnsubo_Click(sender As Object, e As EventArgs) Handles btnsubo.Click
        DashboardSAsuboffer.Show()
        Me.Hide()

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FeedbackSA.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        RefreshDashboard()
        RefreshData()
        SetupAutoRefresh()
    End Sub
End Class