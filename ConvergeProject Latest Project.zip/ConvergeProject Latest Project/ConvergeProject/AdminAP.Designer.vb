﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminAP
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btng = New System.Windows.Forms.Button()
        Me.btnd = New System.Windows.Forms.Button()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btncrud = New System.Windows.Forms.Button()
        Me.lblcount = New System.Windows.Forms.Label()
        Me.btnp = New System.Windows.Forms.Button()
        Me.btnc = New System.Windows.Forms.Button()
        Me.btnci = New System.Windows.Forms.Button()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.dvgclient = New System.Windows.Forms.DataGridView()
        Me.btna = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.btnsubo = New System.Windows.Forms.Button()
        Me.dptdatepick = New System.Windows.Forms.DateTimePicker()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnr
        '
        Me.btnr.Location = New System.Drawing.Point(53, 245)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(83, 34)
        Me.btnr.TabIndex = 74
        Me.btnr.Text = "Report"
        Me.btnr.UseVisualStyleBackColor = True
        '
        'btng
        '
        Me.btng.Location = New System.Drawing.Point(53, 187)
        Me.btng.Name = "btng"
        Me.btng.Size = New System.Drawing.Size(83, 34)
        Me.btng.TabIndex = 73
        Me.btng.Text = "Graph"
        Me.btng.UseVisualStyleBackColor = True
        '
        'btnd
        '
        Me.btnd.Location = New System.Drawing.Point(53, 133)
        Me.btnd.Name = "btnd"
        Me.btnd.Size = New System.Drawing.Size(83, 34)
        Me.btnd.TabIndex = 72
        Me.btnd.Text = "Dashboard"
        Me.btnd.UseVisualStyleBackColor = True
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(53, 637)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 71
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(49, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 20)
        Me.Label1.TabIndex = 70
        Me.Label1.Text = "Super Admin"
        '
        'btncrud
        '
        Me.btncrud.Location = New System.Drawing.Point(781, 136)
        Me.btncrud.Name = "btncrud"
        Me.btncrud.Size = New System.Drawing.Size(105, 33)
        Me.btncrud.TabIndex = 84
        Me.btncrud.Text = "CRUD"
        Me.btncrud.UseVisualStyleBackColor = True
        '
        'lblcount
        '
        Me.lblcount.AutoSize = True
        Me.lblcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcount.Location = New System.Drawing.Point(300, 610)
        Me.lblcount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblcount.Name = "lblcount"
        Me.lblcount.Size = New System.Drawing.Size(0, 20)
        Me.lblcount.TabIndex = 83
        '
        'btnp
        '
        Me.btnp.Location = New System.Drawing.Point(675, 136)
        Me.btnp.Name = "btnp"
        Me.btnp.Size = New System.Drawing.Size(74, 33)
        Me.btnp.TabIndex = 82
        Me.btnp.Text = "Payment"
        Me.btnp.UseVisualStyleBackColor = True
        '
        'btnc
        '
        Me.btnc.Location = New System.Drawing.Point(430, 136)
        Me.btnc.Name = "btnc"
        Me.btnc.Size = New System.Drawing.Size(103, 33)
        Me.btnc.TabIndex = 81
        Me.btnc.Text = "Client Subscription"
        Me.btnc.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnc.UseVisualStyleBackColor = True
        '
        'btnci
        '
        Me.btnci.Location = New System.Drawing.Point(304, 136)
        Me.btnci.Name = "btnci"
        Me.btnci.Size = New System.Drawing.Size(105, 33)
        Me.btnci.TabIndex = 80
        Me.btnci.Text = "Client Information"
        Me.btnci.UseVisualStyleBackColor = True
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(1144, 158)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(83, 26)
        Me.btnsearch.TabIndex = 79
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'dvgclient
        '
        Me.dvgclient.AllowUserToAddRows = False
        Me.dvgclient.AllowUserToDeleteRows = False
        Me.dvgclient.BackgroundColor = System.Drawing.Color.MediumAquamarine
        Me.dvgclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgclient.Location = New System.Drawing.Point(303, 213)
        Me.dvgclient.Name = "dvgclient"
        Me.dvgclient.ReadOnly = True
        Me.dvgclient.Size = New System.Drawing.Size(924, 390)
        Me.dvgclient.TabIndex = 77
        '
        'btna
        '
        Me.btna.Location = New System.Drawing.Point(562, 136)
        Me.btna.Name = "btna"
        Me.btna.Size = New System.Drawing.Size(83, 33)
        Me.btna.TabIndex = 76
        Me.btna.Text = "Appointment"
        Me.btna.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(309, 1240)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 20)
        Me.Label2.TabIndex = 172
        Me.Label2.Text = "Label2"
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView3.Location = New System.Drawing.Point(270, 91)
        Me.DataGridView3.Margin = New System.Windows.Forms.Padding(1)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        Me.DataGridView3.Size = New System.Drawing.Size(996, 573)
        Me.DataGridView3.TabIndex = 178
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(402, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 25)
        Me.Label4.TabIndex = 179
        Me.Label4.Text = "Appointment"
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(1035, 139)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(192, 26)
        Me.txtname.TabIndex = 78
        '
        'btnsubo
        '
        Me.btnsubo.Location = New System.Drawing.Point(53, 296)
        Me.btnsubo.Name = "btnsubo"
        Me.btnsubo.Size = New System.Drawing.Size(83, 34)
        Me.btnsubo.TabIndex = 183
        Me.btnsubo.Text = "Subscription Offer"
        Me.btnsubo.UseVisualStyleBackColor = True
        '
        'dptdatepick
        '
        Me.dptdatepick.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dptdatepick.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dptdatepick.Location = New System.Drawing.Point(956, 173)
        Me.dptdatepick.Name = "dptdatepick"
        Me.dptdatepick.Size = New System.Drawing.Size(271, 26)
        Me.dptdatepick.TabIndex = 206
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox4.Location = New System.Drawing.Point(330, 65)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(267, 48)
        Me.PictureBox4.TabIndex = 180
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.ConvergeProject.My.Resources.Resources.search_icon_png_21
        Me.PictureBox3.Location = New System.Drawing.Point(1011, 138)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 175
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(30, 48)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 69
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(-2, -2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 707)
        Me.PictureBox2.TabIndex = 68
        Me.PictureBox2.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(53, 350)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(83, 34)
        Me.Button2.TabIndex = 207
        Me.Button2.Text = "Feedback "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1144, 99)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 208
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'AdminAP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1350, 705)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.dptdatepick)
        Me.Controls.Add(Me.btnsubo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btncrud)
        Me.Controls.Add(Me.lblcount)
        Me.Controls.Add(Me.btnp)
        Me.Controls.Add(Me.btnc)
        Me.Controls.Add(Me.btnci)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.dvgclient)
        Me.Controls.Add(Me.btna)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btng)
        Me.Controls.Add(Me.btnd)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.btnsearch)
        Me.Name = "AdminAP"
        Me.Text = "DashboardSAAP"
        CType(Me.dvgclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnr As Button
    Friend WithEvents btng As Button
    Friend WithEvents btnd As Button
    Friend WithEvents btnlogout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btncrud As Button
    Friend WithEvents lblcount As Label
    Friend WithEvents btnp As Button
    Friend WithEvents btnc As Button
    Friend WithEvents btnci As Button
    Friend WithEvents btnsearch As Button
    Friend WithEvents dvgclient As DataGridView
    Friend WithEvents btna As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnsubo As Button
    Friend WithEvents dptdatepick As DateTimePicker
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
