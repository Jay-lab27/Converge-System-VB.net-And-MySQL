﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DashboardCF
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtgmail = New System.Windows.Forms.TextBox()
        Me.txtnum = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmbzip = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtId = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnsend = New System.Windows.Forms.Button()
        Me.txtdetail = New System.Windows.Forms.RichTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtmun = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtmname = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtuname = New System.Windows.Forms.TextBox()
        Me.txtname1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnappoint = New System.Windows.Forms.Button()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgvclient = New System.Windows.Forms.DataGridView()
        Me.txtbar = New System.Windows.Forms.TextBox()
        Me.txtpurok = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cmbrate = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmbcat = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.btnhistory = New System.Windows.Forms.Button()
        CType(Me.dgvclient, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(55, 184)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 34)
        Me.Button1.TabIndex = 310
        Me.Button1.Text = "Feedback"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtgmail
        '
        Me.txtgmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgmail.Location = New System.Drawing.Point(951, 223)
        Me.txtgmail.Name = "txtgmail"
        Me.txtgmail.Size = New System.Drawing.Size(251, 26)
        Me.txtgmail.TabIndex = 304
        '
        'txtnum
        '
        Me.txtnum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnum.Location = New System.Drawing.Point(623, 464)
        Me.txtnum.Name = "txtnum"
        Me.txtnum.Size = New System.Drawing.Size(252, 26)
        Me.txtnum.TabIndex = 303
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(948, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 20)
        Me.Label7.TabIndex = 302
        Me.Label7.Text = "Gmail:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(620, 441)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(129, 20)
        Me.Label9.TabIndex = 301
        Me.Label9.Text = "Contact Number:"
        '
        'cmbzip
        '
        Me.cmbzip.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbzip.FormattingEnabled = True
        Me.cmbzip.Items.AddRange(New Object() {"", "4600", "4601", "4604", "4608", "4602", "4603", "4606", "4605", "4609", " 4611"})
        Me.cmbzip.Location = New System.Drawing.Point(626, 392)
        Me.cmbzip.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbzip.Name = "cmbzip"
        Me.cmbzip.Size = New System.Drawing.Size(257, 26)
        Me.cmbzip.TabIndex = 300
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(622, 369)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 20)
        Me.Label12.TabIndex = 299
        Me.Label12.Text = "Zip Code:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(315, 195)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 20)
        Me.Label5.TabIndex = 298
        Me.Label5.Text = "User ID:"
        '
        'txtId
        '
        Me.txtId.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtId.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtId.Location = New System.Drawing.Point(319, 217)
        Me.txtId.Margin = New System.Windows.Forms.Padding(2)
        Me.txtId.Name = "txtId"
        Me.txtId.Size = New System.Drawing.Size(251, 26)
        Me.txtId.TabIndex = 297
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.MediumAquamarine
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(391, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 25)
        Me.Label4.TabIndex = 293
        Me.Label4.Text = "Feedback"
        '
        'btnsend
        '
        Me.btnsend.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnsend.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsend.Location = New System.Drawing.Point(1048, 509)
        Me.btnsend.Name = "btnsend"
        Me.btnsend.Size = New System.Drawing.Size(154, 35)
        Me.btnsend.TabIndex = 292
        Me.btnsend.Text = "Send"
        Me.btnsend.UseVisualStyleBackColor = False
        '
        'txtdetail
        '
        Me.txtdetail.Location = New System.Drawing.Point(946, 412)
        Me.txtdetail.Name = "txtdetail"
        Me.txtdetail.Size = New System.Drawing.Size(256, 78)
        Me.txtdetail.TabIndex = 291
        Me.txtdetail.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(947, 389)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(129, 20)
        Me.Label6.TabIndex = 290
        Me.Label6.Text = "Feedback Detail:"
        '
        'txtmun
        '
        Me.txtmun.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmun.FormattingEnabled = True
        Me.txtmun.Items.AddRange(New Object() {"Daet", "Mercedes", "Labo", "Basud", "San Lorenzo Ruiz", "Talisay", "Vinzons", "Jose Panganiban", "Paracale", "Capalonga", "San Vicente", "Sta. Elena"})
        Me.txtmun.Location = New System.Drawing.Point(625, 336)
        Me.txtmun.Margin = New System.Windows.Forms.Padding(2)
        Me.txtmun.Name = "txtmun"
        Me.txtmun.Size = New System.Drawing.Size(256, 28)
        Me.txtmun.TabIndex = 287
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(621, 314)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(94, 20)
        Me.Label8.TabIndex = 284
        Me.Label8.Text = "Municipality:"
        '
        'txtmname
        '
        Me.txtmname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmname.Location = New System.Drawing.Point(319, 464)
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(251, 26)
        Me.txtmname.TabIndex = 283
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label14.Location = New System.Drawing.Point(315, 441)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(105, 20)
        Me.Label14.TabIndex = 282
        Me.Label14.Text = "Middle Name:"
        '
        'txtfname
        '
        Me.txtfname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfname.Location = New System.Drawing.Point(319, 403)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(251, 26)
        Me.txtfname.TabIndex = 281
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Location = New System.Drawing.Point(315, 380)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 20)
        Me.Label13.TabIndex = 280
        Me.Label13.Text = "First Name:"
        '
        'txtuname
        '
        Me.txtuname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtuname.Location = New System.Drawing.Point(319, 276)
        Me.txtuname.Name = "txtuname"
        Me.txtuname.Size = New System.Drawing.Size(251, 26)
        Me.txtuname.TabIndex = 279
        '
        'txtname1
        '
        Me.txtname1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname1.Location = New System.Drawing.Point(319, 340)
        Me.txtname1.Name = "txtname1"
        Me.txtname1.Size = New System.Drawing.Size(251, 26)
        Me.txtname1.TabIndex = 278
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(315, 253)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 20)
        Me.Label2.TabIndex = 277
        Me.Label2.Text = "User Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(319, 318)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 20)
        Me.Label3.TabIndex = 276
        Me.Label3.Text = "Last Name:"
        '
        'btnappoint
        '
        Me.btnappoint.Location = New System.Drawing.Point(55, 125)
        Me.btnappoint.Name = "btnappoint"
        Me.btnappoint.Size = New System.Drawing.Size(83, 34)
        Me.btnappoint.TabIndex = 275
        Me.btnappoint.Text = "Appointment"
        Me.btnappoint.UseVisualStyleBackColor = True
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.Firebrick
        Me.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlogout.Location = New System.Drawing.Point(55, 639)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(83, 34)
        Me.btnlogout.TabIndex = 274
        Me.btnlogout.Text = "Log out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(60, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 20)
        Me.Label1.TabIndex = 273
        Me.Label1.Text = "Customer"
        '
        'dgvclient
        '
        Me.dgvclient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvclient.Location = New System.Drawing.Point(1087, 160)
        Me.dgvclient.Name = "dgvclient"
        Me.dgvclient.Size = New System.Drawing.Size(90, 28)
        Me.dgvclient.TabIndex = 296
        '
        'txtbar
        '
        Me.txtbar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbar.Location = New System.Drawing.Point(624, 276)
        Me.txtbar.Name = "txtbar"
        Me.txtbar.Size = New System.Drawing.Size(256, 26)
        Me.txtbar.TabIndex = 318
        '
        'txtpurok
        '
        Me.txtpurok.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpurok.Location = New System.Drawing.Point(624, 215)
        Me.txtpurok.Name = "txtpurok"
        Me.txtpurok.Size = New System.Drawing.Size(256, 26)
        Me.txtpurok.TabIndex = 317
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(622, 192)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 20)
        Me.Label16.TabIndex = 316
        Me.Label16.Text = "Purok:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(621, 253)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(81, 20)
        Me.Label15.TabIndex = 315
        Me.Label15.Text = "Barangay:"
        '
        'cmbrate
        '
        Me.cmbrate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbrate.FormattingEnabled = True
        Me.cmbrate.Items.AddRange(New Object() {"1. Bad", "2. Average", "3. Good", "4. Very Good", "5. Great"})
        Me.cmbrate.Location = New System.Drawing.Point(946, 278)
        Me.cmbrate.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbrate.Name = "cmbrate"
        Me.cmbrate.Size = New System.Drawing.Size(256, 28)
        Me.cmbrate.TabIndex = 320
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(942, 256)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 20)
        Me.Label10.TabIndex = 319
        Me.Label10.Text = "Service Rating:"
        '
        'cmbcat
        '
        Me.cmbcat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcat.FormattingEnabled = True
        Me.cmbcat.Items.AddRange(New Object() {"Complaint", "Suggestion", "Praise"})
        Me.cmbcat.Location = New System.Drawing.Point(946, 342)
        Me.cmbcat.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbcat.Name = "cmbcat"
        Me.cmbcat.Size = New System.Drawing.Size(256, 28)
        Me.cmbcat.TabIndex = 322
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(942, 320)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(152, 20)
        Me.Label11.TabIndex = 321
        Me.Label11.Text = "Feedback Category:"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox1.Location = New System.Drawing.Point(30, 48)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(136, 48)
        Me.PictureBox1.TabIndex = 272
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox2.Location = New System.Drawing.Point(-2, -2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(204, 701)
        Me.PictureBox2.TabIndex = 271
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.MediumAquamarine
        Me.PictureBox3.Location = New System.Drawing.Point(319, 123)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(267, 48)
        Me.PictureBox3.TabIndex = 294
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox4.Location = New System.Drawing.Point(255, 153)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(1020, 418)
        Me.PictureBox4.TabIndex = 295
        Me.PictureBox4.TabStop = False
        '
        'btnhistory
        '
        Me.btnhistory.Location = New System.Drawing.Point(55, 240)
        Me.btnhistory.Name = "btnhistory"
        Me.btnhistory.Size = New System.Drawing.Size(83, 34)
        Me.btnhistory.TabIndex = 355
        Me.btnhistory.Text = "Payment History"
        Me.btnhistory.UseVisualStyleBackColor = True
        '
        'DashboardCF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1347, 700)
        Me.Controls.Add(Me.btnhistory)
        Me.Controls.Add(Me.cmbcat)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.cmbrate)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtbar)
        Me.Controls.Add(Me.txtpurok)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtgmail)
        Me.Controls.Add(Me.txtnum)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cmbzip)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtId)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnsend)
        Me.Controls.Add(Me.txtdetail)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtmun)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtmname)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtfname)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtuname)
        Me.Controls.Add(Me.txtname1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnappoint)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.dgvclient)
        Me.Name = "DashboardCF"
        Me.Text = "y"
        CType(Me.dgvclient, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents txtgmail As TextBox
    Friend WithEvents txtnum As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents cmbzip As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtId As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnsend As Button
    Friend WithEvents txtdetail As RichTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtmun As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtmname As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtfname As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtuname As TextBox
    Friend WithEvents txtname1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnappoint As Button
    Friend WithEvents btnlogout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents dgvclient As DataGridView
    Friend WithEvents txtbar As TextBox
    Friend WithEvents txtpurok As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents cmbrate As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents cmbcat As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnhistory As Button
End Class
