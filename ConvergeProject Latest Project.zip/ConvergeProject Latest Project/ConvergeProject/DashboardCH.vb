﻿Imports MySql.Data.MySqlClient

Public Class DashboardCH
    Dim count As Integer = 0
    Dim timer As New Timer()

    Private Sub DashboardCH_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Maximized
        Try
            SetupAutoRefresh()
            RefreshDashboard()
            LoadPaymentsForClient()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Public Sub RefreshDashboard()
        LoadPaymentsForClient()
    End Sub


    Private Sub SetupAutoRefresh()
        Dim refreshTimer As New Timer()
        AddHandler refreshTimer.Tick, AddressOf AutoRefresh
        refreshTimer.Interval = 3000 ' Refresh every 5 seconds
        refreshTimer.Start()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs)
        Try
            ' Check for changes in the row count
            Dim newCount As Integer = GetRowCount("SELECT COUNT(*) FROM `payments`;")
            If newCount <> count Then
                count = newCount
                RefreshDashboard() ' Refresh the DataGridView if there are changes
                LoadPaymentsForClient()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Function GetRowCount(query As String) As Integer

        Dim rowCount As Integer = 0
        Using connection As New MySqlConnection("strConnection")
            connection.Open()
            Using command As New MySqlCommand(query, connection)
                rowCount = Convert.ToInt32(command.ExecuteScalar())
            End Using
        End Using
        Return rowCount
    End Function

    Private Sub AutoRefresh(sender As Object, e As EventArgs)
        Try
            Using connection As New MySqlConnection(strConnection)
                connection.Open()
                Dim query As String = "SELECT COUNT(*) FROM `payments`;"
                Dim newCount As Integer
                Using cmd As New MySqlCommand(query, connection)
                    newCount = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                ' Refresh data if new rows are detected
                If newCount <> count Then
                    RefreshDashboard()

                    SetupAutoRefresh()
                    LoadPaymentsForClient()

                End If
            End Using
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub





    Private Sub LoadPaymentsForClient()
        Try
            ' Ensure there is a logged user
            If CurrentLoggedUser.Equals(New LoggedUser()) OrElse String.IsNullOrEmpty(CurrentLoggedUser.username) Then
                MessageBox.Show("No logged-in user detected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If


            Dim connString As String = strConnection

            Using conn As New MySqlConnection(connString)
                conn.Open()

                Dim query As String = "
                SELECT 
                    Id AS 'Payment ID', 
                    UserID AS 'User ID',
                    Lastname AS 'Last Name', 
                    Firstname AS 'First Name', 
                    Middlename AS 'Middle Name', 
                    Purok, 
                    Barangay, 
                    Municipality, 
                    Zipcode AS 'Zip Code', 
                    Payment AS 'Payment Amount', 
                    Dateofpayment AS 'Date of Payment', 
                    Duedate AS 'Due Date', 
                    Latefeecharge AS 'Late Fee Charge', 
                    Paymentnote AS 'Payment Note'
                FROM 
                    `payments` 
                WHERE 
                    Username = @username"

                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@username", CurrentLoggedUser.username)

                    ' Execute query and load data into a DataTable
                    Using adapter As New MySqlDataAdapter(cmd)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)

                        ' Bind DataTable to DataGridView
                        dgvclient.DataSource = dataTable

                        ' Adjust column widths for better readability
                        dgvclient.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred while loading payment data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Try
            ' Pop up pra pag log-out
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to logout?", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            ' Result sa logout
            If result = DialogResult.Yes Then
                Form1.txtuname.Clear()
                Form1.txtpass.Clear()

                Form1.Show()
                Me.Close()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub btnappoint_Click(sender As Object, e As EventArgs) Handles btnappoint.Click
        DashboardC.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DashboardCF.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        SetupAutoRefresh()
        RefreshDashboard()
        LoadPaymentsForClient()

    End Sub
End Class