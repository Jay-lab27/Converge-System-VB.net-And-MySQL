﻿Imports System.IO

Public Class AdminConnection
    Private Sub AdminConnection_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        ' Update the connection string and save it to the config file
        Try
            Dim newConnectionString As String = $"server={txtServer.Text};uid={txtUserID.Text};password={txtPassword.Text};database={txtDatabase.Text};allowuservariables=True;"

            ' Save to config.txt
            Dim configPath As String = Path.Combine(Directory.GetCurrentDirectory(), "config.txt")
            Using writer As StreamWriter = New StreamWriter(configPath, False)
                writer.WriteLine($"server={txtServer.Text}")
                writer.WriteLine($"uid={txtUserID.Text}")
                writer.WriteLine($"password={txtPassword.Text}")
                writer.WriteLine($"database={txtDatabase.Text}")
            End Using

            ' Update the global connection string
            strConnection = newConnectionString

            MessageBox.Show("Connection string updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        Catch ex As Exception
            MessageBox.Show($"Error saving connection string: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btncanel_Click(sender As Object, e As EventArgs) Handles btncanel.Click
        Me.Close() ' Close the form without saving
    End Sub
End Class