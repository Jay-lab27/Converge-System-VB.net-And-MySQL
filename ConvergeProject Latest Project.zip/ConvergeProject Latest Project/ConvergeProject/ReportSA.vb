﻿
Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.IO
Imports Microsoft.Office.Interop.Excel
Imports System.Runtime.InteropServices
Public Class ReportSA
    Private Sub btncon_Click(sender As Object, e As EventArgs) Handles btncon.Click
        If cmbreport.SelectedItem Is Nothing Or String.IsNullOrEmpty(txtreportn.Text) Then
            MessageBox.Show("Please select a report and provide a file name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim query As String = ""
        If cmbreport.SelectedItem.ToString() = "Client Info Record" Then
            query = "SELECT * FROM clientinfo"
            Log("Export an Client Info Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Admin Info Record" Then
            query = "SELECT * FROM admin"
            Log("Export an Admin info Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")


        ElseIf cmbreport.SelectedItem.ToString() = "Client Subscription Record" Then
            query = "SELECT * FROM subscription "
            Log("Export an Subscription Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Payment Record" Then
            query = "SELECT * FROM payments "
            Log("Export an Payment Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Subscription Service Record" Then
            query = "SELECT * FROM availablesubscription "
            Log("Export an Subscription Service Record " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Feedback Record" Then
            query = "SELECT * FROM feedback"
            Log("Export an Feedback Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Appointment Record" Then
            query = "SELECT * FROM appointment "
            Log("Export an Appointment Records " & "by: " & CurrentLoggedUser.username, "btnexport_Click")

        ElseIf cmbreport.SelectedItem.ToString() = "Logs Report" Then
            query = "SELECT * FROM logs"
            Log("Export an logs report " & "by: " & CurrentLoggedUser.username, "btnexport_Click")


        ElseIf cmbreport.SelectedItem.ToString() = "Monthly Revenue Record" Then

            If daterev.Value <> DateTime.MinValue Then
                ' Get the selected month and year
                Dim selectedDate As Date = daterev.Value.Date
                Dim month As Integer = selectedDate.Month
                Dim year As Integer = selectedDate.Year

                Dim startDate As New Date(year, month, 1) ' First day of the selected month
                Dim endDate As Date


                If month = 12 Then
                    ' For December, the end date should be the last day of December
                    endDate = New Date(year, month, 31)
                Else
                    ' For other months, calculate the end date as the last day of the selected month
                    endDate = startDate.AddMonths(1).AddDays(-1)
                End If

                ' Modified query to include the total number of paid clients
                query = $"SELECT Municipality, 
                        SUM(Payment) AS Payment, 
                        SUM(Latefeecharge) AS Latefeecharges,
                        COUNT(DISTINCT UserID) AS TotalPaidClients
                 FROM payments
                 WHERE Dateofpayment BETWEEN '{startDate:yyyy-MM-dd}' AND '{endDate:yyyy-MM-dd}'
                 GROUP BY Municipality"

                Log($"Export Monthly Revenue Record for {selectedDate:yyyy-MM} by: {CurrentLoggedUser.username}", "btnexport_Click")
            Else
                MessageBox.Show("Please select a date for the Monthly Revenue Record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return ' Exit the method early if no date is selected
            End If
        End If

        Dim projectFolder As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ConvergeProject", "Export")
        If Not Directory.Exists(projectFolder) Then
            Directory.CreateDirectory(projectFolder)
        End If

        Dim excelFilePath As String = Path.Combine(projectFolder, $"{txtreportn.Text}.xlsx")

        Dim dt As New System.Data.DataTable()

        Try
            ' Ensure the connection is using strConnection
            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim adapter As New MySqlDataAdapter(query, conn)
                adapter.Fill(dt) ' 
            End Using


            ExportToExcel(dt, excelFilePath)

            MessageBox.Show($"Report exported successfully to:\nExcel: {excelFilePath}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show($"Error exporting report: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub ExportToExcel(dt As System.Data.DataTable, filePath As String)
        Dim excelApp As New Application()
        Dim workBook As Workbook = excelApp.Workbooks.Add()
        Dim worksheet As Worksheet = CType(workBook.Sheets(1), Worksheet)

        ' Add report title and date/time
        worksheet.Cells(1, 1).Value = "Report: " & cmbreport.SelectedItem.ToString()
        worksheet.Cells(2, 1).Value = "Date and Time: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        worksheet.Cells(1, 1).Font.Size = 16
        worksheet.Cells(1, 1).Font.Bold = True
        worksheet.Cells(2, 1).Font.Size = 13
        ' Add User Information
        worksheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
        worksheet.Cells(3, 1).Font.Size = 13 '

        For colIndex As Integer = 0 To dt.Columns.Count - 1
            worksheet.Cells(4, colIndex + 1).Value = dt.Columns(colIndex).ColumnName
        Next

        For rowIndex As Integer = 0 To dt.Rows.Count - 1
            For colIndex As Integer = 0 To dt.Columns.Count - 1
                worksheet.Cells(rowIndex + 5, colIndex + 1).Value = dt.Rows(rowIndex)(colIndex)
            Next
        Next






        If cmbreport.SelectedItem.ToString() = "Monthly Revenue Record" Then
            Dim summarySheet As Worksheet = workBook.Sheets.Add(After:=worksheet)
            summarySheet.Name = "Summary"

            summarySheet.Cells(1, 1).Value = "Report: Monthly Revenue Record"
            summarySheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            summarySheet.Cells(1, 1).Font.Size = 16
            summarySheet.Cells(1, 1).Font.Bold = True
            summarySheet.Cells(2, 1).Font.Size = 13




            summarySheet.Cells(4, 1).Value = "Municipality"
            summarySheet.Cells(4, 3).Value = "Payment:"
            summarySheet.Cells(4, 4).Value = "Late fee charges"
            summarySheet.Cells(4, 5).Value = "Total of Payment and Charges"
            summarySheet.Cells(4, 2).Value = "Total Client"

            summarySheet.Cells(4, 1).Font.Bold = True
            summarySheet.Cells(4, 2).Font.Bold = True
            summarySheet.Cells(4, 3).Font.Bold = True
            summarySheet.Cells(4, 4).Font.Bold = True
            summarySheet.Cells(4, 5).Font.Bold = True


            Dim totalRevenue As Decimal = 0
            Dim totalPaidClients As Integer = 0 ' To calculate the total number of paid clients

            ' Loop through the rows and populate the summary sheet
            For rowIndex As Integer = 0 To dt.Rows.Count - 1
                Dim payment As Decimal = Convert.ToDecimal(dt.Rows(rowIndex)("Payment"))
                Dim lateFee As Decimal = Convert.ToDecimal(dt.Rows(rowIndex)("Latefeecharges"))
                Dim total As Decimal = payment + lateFee
                Dim paidClients As Integer = Convert.ToInt32(dt.Rows(rowIndex)("TotalPaidClients"))

                summarySheet.Cells(rowIndex + 5, 1).Value = dt.Rows(rowIndex)("Municipality").ToString()
                summarySheet.Cells(rowIndex + 5, 3).Value = payment
                summarySheet.Cells(rowIndex + 5, 4).Value = lateFee
                summarySheet.Cells(rowIndex + 5, 5).Value = total
                summarySheet.Cells(rowIndex + 5, 2).Value = paidClients ' Add the Total Paid Clients value

                totalRevenue += total
                totalPaidClients += paidClients
            Next

            ' Add total revenue and total paid clients at the bottom
            summarySheet.Cells(dt.Rows.Count + 5, 4).Value = "Total Revenue"
            summarySheet.Cells(dt.Rows.Count + 5, 5).Value = totalRevenue
            summarySheet.Cells(dt.Rows.Count + 5, 4).Font.Bold = True
            summarySheet.Cells(dt.Rows.Count + 5, 5).Font.Bold = True

            summarySheet.Cells(dt.Rows.Count + 6, 1).Value = "Total Paid Clients"
            summarySheet.Cells(dt.Rows.Count + 6, 2).Value = totalPaidClients
            summarySheet.Cells(dt.Rows.Count + 6, 1).Font.Bold = True
            summarySheet.Cells(dt.Rows.Count + 6, 2).Font.Bold = True
        End If









        If cmbreport.SelectedItem.ToString() = "Admin Info Record" Then
            Dim summarySheet As Microsoft.Office.Interop.Excel.Worksheet = workBook.Sheets.Add(After:=worksheet)
            summarySheet.Name = "Sheet2"

            summarySheet.Cells(1, 1).Value = "Report: Admin Info Record"
            summarySheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            summarySheet.Cells(1, 1).Font.Size = 16
            summarySheet.Cells(1, 1).Font.Bold = True
            summarySheet.Cells(2, 1).Font.Size = 13 ' 

            If Not CurrentLoggedUser.Equals(Nothing) Then
                summarySheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
                summarySheet.Cells(3, 1).Font.Size = 13 '
                summarySheet.Cells(3, 2).Font.Size = 13
            End If

            summarySheet.Cells(5, 1).Value = "Municipality"
            summarySheet.Cells(5, 2).Value = "Super Admin Count"
            summarySheet.Cells(5, 3).Value = "Admin Count"
            summarySheet.Cells(5, 1).Font.Bold = True
            summarySheet.Cells(5, 2).Font.Bold = True
            summarySheet.Cells(5, 3).Font.Bold = True

            ' Query to get the count of Super Admin and Admin in each municipality
            Dim summaryQuery As String = "SELECT Municipality, " &
                                 "SUM(CASE WHEN Position = 'SuperAdmin' THEN 1 ELSE 0 END) AS SuperAdminCount, " &
                                 "SUM(CASE WHEN Position = 'Admin' THEN 1 ELSE 0 END) AS AdminCount " &
                                 "FROM admin GROUP BY Municipality"
            Dim summaryDt As New System.Data.DataTable()

            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim summaryAdapter As New MySqlDataAdapter(summaryQuery, conn)
                summaryAdapter.Fill(summaryDt)
            End Using

            Dim totalSuperAdmins As Integer = 0
            Dim totalAdmins As Integer = 0

            For rowIndex As Integer = 0 To summaryDt.Rows.Count - 1
                summarySheet.Cells(rowIndex + 6, 1).Value = summaryDt.Rows(rowIndex)("Municipality").ToString()
                summarySheet.Cells(rowIndex + 6, 2).Value = summaryDt.Rows(rowIndex)("SuperAdminCount").ToString()
                summarySheet.Cells(rowIndex + 6, 3).Value = summaryDt.Rows(rowIndex)("AdminCount").ToString()

                totalSuperAdmins += Convert.ToInt32(summaryDt.Rows(rowIndex)("SuperAdminCount"))
                totalAdmins += Convert.ToInt32(summaryDt.Rows(rowIndex)("AdminCount"))
            Next

            ' Adding total row
            Dim totalRow As Integer = summaryDt.Rows.Count + 6
            summarySheet.Cells(totalRow, 1).Value = "Total"
            summarySheet.Cells(totalRow, 2).Value = totalSuperAdmins
            summarySheet.Cells(totalRow, 3).Value = totalAdmins
            summarySheet.Cells(totalRow, 1).Font.Bold = True
            summarySheet.Cells(totalRow, 2).Font.Bold = True
            summarySheet.Cells(totalRow, 3).Font.Bold = True
        End If





        If cmbreport.SelectedItem.ToString() = "Feedback Record" Then
            Dim feedbackSheet As Microsoft.Office.Interop.Excel.Worksheet = workBook.Sheets.Add(After:=worksheet)
            feedbackSheet.Name = "Service Ratings"

            feedbackSheet.Cells(1, 1).Value = "Report: Service Rating Record"
            feedbackSheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            feedbackSheet.Cells(1, 1).Font.Size = 16
            feedbackSheet.Cells(1, 1).Font.Bold = True
            feedbackSheet.Cells(2, 1).Font.Size = 13

            If Not CurrentLoggedUser.Equals(Nothing) Then
                feedbackSheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
                feedbackSheet.Cells(3, 1).Font.Size = 13
                feedbackSheet.Cells(3, 1).Font.Size = 13
            End If

            feedbackSheet.Cells(5, 1).Value = "Municipality"
            feedbackSheet.Cells(5, 2).Value = "Bad"
            feedbackSheet.Cells(5, 3).Value = "Average"
            feedbackSheet.Cells(5, 4).Value = "Good"
            feedbackSheet.Cells(5, 5).Value = "Very Good"
            feedbackSheet.Cells(5, 6).Value = "Great"
            feedbackSheet.Cells(5, 1).Font.Bold = True
            feedbackSheet.Cells(5, 2).Font.Bold = True
            feedbackSheet.Cells(5, 3).Font.Bold = True
            feedbackSheet.Cells(5, 4).Font.Bold = True
            feedbackSheet.Cells(5, 5).Font.Bold = True
            feedbackSheet.Cells(5, 6).Font.Bold = True

            ' Query to get the count of each ServiceRating for each municipality
            Dim feedbackQuery As String = "SELECT Municipality, " &
                                  "SUM(CASE WHEN Servicerating = '1. Bad' THEN 1 ELSE 0 END) AS BadCount, " &
                                  "SUM(CASE WHEN Servicerating = '2. Average' THEN 1 ELSE 0 END) AS AverageCount, " &
                                  "SUM(CASE WHEN Servicerating = '3. Good' THEN 1 ELSE 0 END) AS GoodCount, " &
                                  "SUM(CASE WHEN Servicerating = '4. Very Good' THEN 1 ELSE 0 END) AS VeryGoodCount, " &
                                  "SUM(CASE WHEN Servicerating = '5. Great' THEN 1 ELSE 0 END) AS GreatCount " &
                                  "FROM feedback GROUP BY Municipality"
            Dim feedbackDt As New System.Data.DataTable()

            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim feedbackAdapter As New MySqlDataAdapter(feedbackQuery, conn)
                feedbackAdapter.Fill(feedbackDt)
            End Using

            For rowIndex As Integer = 0 To feedbackDt.Rows.Count - 1
                feedbackSheet.Cells(rowIndex + 6, 1).Value = feedbackDt.Rows(rowIndex)("Municipality").ToString()
                feedbackSheet.Cells(rowIndex + 6, 2).Value = feedbackDt.Rows(rowIndex)("BadCount").ToString()
                feedbackSheet.Cells(rowIndex + 6, 3).Value = feedbackDt.Rows(rowIndex)("AverageCount").ToString()
                feedbackSheet.Cells(rowIndex + 6, 4).Value = feedbackDt.Rows(rowIndex)("GoodCount").ToString()
                feedbackSheet.Cells(rowIndex + 6, 5).Value = feedbackDt.Rows(rowIndex)("VeryGoodCount").ToString()
                feedbackSheet.Cells(rowIndex + 6, 6).Value = feedbackDt.Rows(rowIndex)("GreatCount").ToString()
            Next

            ' Adding total row
            Dim totalRow As Integer = feedbackDt.Rows.Count + 6
            feedbackSheet.Cells(totalRow, 1).Value = "Total"
            feedbackSheet.Cells(totalRow, 2).Value = feedbackDt.Compute("SUM(BadCount)", "").ToString()
            feedbackSheet.Cells(totalRow, 3).Value = feedbackDt.Compute("SUM(AverageCount)", "").ToString()
            feedbackSheet.Cells(totalRow, 4).Value = feedbackDt.Compute("SUM(GoodCount)", "").ToString()
            feedbackSheet.Cells(totalRow, 5).Value = feedbackDt.Compute("SUM(VeryGoodCount)", "").ToString()
            feedbackSheet.Cells(totalRow, 6).Value = feedbackDt.Compute("SUM(GreatCount)", "").ToString()
            feedbackSheet.Cells(totalRow, 1).Font.Bold = True
            feedbackSheet.Cells(totalRow, 2).Font.Bold = True
            feedbackSheet.Cells(totalRow, 3).Font.Bold = True
            feedbackSheet.Cells(totalRow, 4).Font.Bold = True
            feedbackSheet.Cells(totalRow, 5).Font.Bold = True
            feedbackSheet.Cells(totalRow, 6).Font.Bold = True
        End If












        If cmbreport.SelectedItem.ToString() = "Client Info Record" Then
            Dim summarySheet As Microsoft.Office.Interop.Excel.Worksheet = workBook.Sheets.Add(After:=worksheet)
            summarySheet.Name = "Sheet2"

            summarySheet.Cells(1, 1).Value = "Report: Client Info Record "
            summarySheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            summarySheet.Cells(1, 1).Font.Size = 16
            summarySheet.Cells(1, 1).Font.Bold = True
            summarySheet.Cells(2, 1).Font.Size = 13 ' 

            If Not CurrentLoggedUser.Equals(Nothing) Then
                summarySheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
                summarySheet.Cells(3, 1).Font.Size = 13 '
                summarySheet.Cells(3, 2).Font.Size = 13
            End If


            summarySheet.Cells(5, 1).Value = "Municipality"
            summarySheet.Cells(5, 2).Value = "Number of Clients"
            summarySheet.Cells(5, 1).Font.Bold = True
            summarySheet.Cells(5, 2).Font.Bold = True


            Dim summaryQuery = "SELECT Municipality, COUNT(*) AS ClientCount FROM clientinfo GROUP BY Municipality"
            Dim summaryDt As New System.Data.DataTable()

            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim summaryAdapter As New MySqlDataAdapter(summaryQuery, conn)
                summaryAdapter.Fill(summaryDt)
            End Using


            Dim totalClients As Integer = 0
            For rowIndex As Integer = 0 To summaryDt.Rows.Count - 1
                summarySheet.Cells(rowIndex + 6, 1).Value = summaryDt.Rows(rowIndex)("Municipality").ToString()
                summarySheet.Cells(rowIndex + 6, 2).Value = summaryDt.Rows(rowIndex)("ClientCount").ToString()
                totalClients += Convert.ToInt32(summaryDt.Rows(rowIndex)("ClientCount"))
            Next


            Dim totalRow As Integer = summaryDt.Rows.Count + 6
            summarySheet.Cells(totalRow, 1).Value = "Total Clients"
            summarySheet.Cells(totalRow, 2).Value = totalClients
            summarySheet.Cells(totalRow, 1).Font.Bold = True
            summarySheet.Cells(totalRow, 2).Font.Bold = True
        End If












        If cmbreport.SelectedItem.ToString() = "Client Subscription Record" Then
            Dim summarySheet As Microsoft.Office.Interop.Excel.Worksheet = workBook.Sheets.Add(After:=worksheet)
            summarySheet.Name = "Sheet2"

            summarySheet.Cells(1, 1).Value = "Report: Client Subscription Record"
            summarySheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            summarySheet.Cells(1, 1).Font.Size = 16
            summarySheet.Cells(1, 1).Font.Bold = True
            summarySheet.Cells(2, 1).Font.Size = 13

            If Not CurrentLoggedUser.Equals(Nothing) Then
                summarySheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
                summarySheet.Cells(3, 1).Font.Size = 13
                summarySheet.Cells(3, 2).Font.Size = 13
            End If

            summarySheet.Cells(5, 1).Value = "Subscription"
            summarySheet.Cells(5, 2).Value = "Number of Subscriptions"
            summarySheet.Cells(5, 1).Font.Bold = True
            summarySheet.Cells(5, 2).Font.Bold = True


            Dim summaryQuery As String = "SELECT Subscription, COUNT(*) AS SubscriptionCount FROM subscription GROUP BY Subscription"
            Dim summaryDt As New System.Data.DataTable()

            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim summaryAdapter As New MySqlDataAdapter(summaryQuery, conn)
                summaryAdapter.Fill(summaryDt)
            End Using

            Dim totalSubscriptions As Integer = 0
            For rowIndex As Integer = 0 To summaryDt.Rows.Count - 1
                summarySheet.Cells(rowIndex + 6, 1).Value = summaryDt.Rows(rowIndex)("Subscription").ToString()
                summarySheet.Cells(rowIndex + 6, 2).Value = summaryDt.Rows(rowIndex)("SubscriptionCount").ToString()
                totalSubscriptions += Convert.ToInt32(summaryDt.Rows(rowIndex)("SubscriptionCount"))
            Next

            Dim totalRow As Integer = summaryDt.Rows.Count + 6
            summarySheet.Cells(totalRow, 1).Value = "Total Subscriptions"
            summarySheet.Cells(totalRow, 2).Value = totalSubscriptions
            summarySheet.Cells(totalRow, 1).Font.Bold = True
            summarySheet.Cells(totalRow, 2).Font.Bold = True
        End If

        If cmbreport.SelectedItem.ToString() = "Payment Record" Then
            Dim paymentSheet As Microsoft.Office.Interop.Excel.Worksheet = workBook.Sheets.Add(After:=worksheet)
            paymentSheet.Name = "Sheet2"

            paymentSheet.Cells(1, 1).Value = "Report: Payment Record"
            paymentSheet.Cells(2, 1).Value = "Generated on: " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            paymentSheet.Cells(1, 1).Font.Size = 16
            paymentSheet.Cells(1, 1).Font.Bold = True
            paymentSheet.Cells(2, 1).Font.Size = 13

            If Not CurrentLoggedUser.Equals(Nothing) Then
                paymentSheet.Cells(3, 1).Value = "Exported By: ID:" & " " & CurrentLoggedUser.id & " Username: " & " " & CurrentLoggedUser.username
                paymentSheet.Cells(3, 1).Font.Size = 13
                paymentSheet.Cells(3, 2).Font.Size = 13
            End If

            paymentSheet.Cells(5, 1).Value = "Municipality"
            paymentSheet.Cells(5, 2).Value = "Payment"
            paymentSheet.Cells(5, 3).Value = "Late Fee Charge"
            paymentSheet.Cells(5, 4).Value = "Total Payment & Late Fee"
            paymentSheet.Cells(5, 1).Font.Bold = True
            paymentSheet.Cells(5, 2).Font.Bold = True
            paymentSheet.Cells(5, 3).Font.Bold = True
            paymentSheet.Cells(5, 4).Font.Bold = True


            Dim paymentQuery As String = "SELECT Municipality, SUM(Payment) AS TotalPayment, SUM(Latefeecharge) AS TotalLateFee FROM payments GROUP BY Municipality"
            Dim paymentDt As New System.Data.DataTable()

            Using conn As New MySqlConnection(strConnection)
                conn.Open()
                Dim paymentAdapter As New MySqlDataAdapter(paymentQuery, conn)
                paymentAdapter.Fill(paymentDt)
            End Using

            Dim totalPayment As Decimal = 0
            Dim totalLateFee As Decimal = 0
            Dim grandTotal As Decimal = 0
            For rowIndex As Integer = 0 To paymentDt.Rows.Count - 1
                paymentSheet.Cells(rowIndex + 6, 1).Value = paymentDt.Rows(rowIndex)("Municipality").ToString()
                paymentSheet.Cells(rowIndex + 6, 2).Value = Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalPayment")).ToString("C2")
                paymentSheet.Cells(rowIndex + 6, 3).Value = Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalLateFee")).ToString("C2")


                Dim total As Decimal = Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalPayment")) + Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalLateFee"))
                paymentSheet.Cells(rowIndex + 6, 4).Value = total.ToString("C2")


                totalPayment += Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalPayment"))
                totalLateFee += Convert.ToDecimal(paymentDt.Rows(rowIndex)("TotalLateFee"))
                grandTotal += total
            Next

            Dim totalRow As Integer = paymentDt.Rows.Count + 6
            paymentSheet.Cells(totalRow, 1).Value = "Total"
            paymentSheet.Cells(totalRow, 2).Value = totalPayment.ToString("C2")
            paymentSheet.Cells(totalRow, 3).Value = totalLateFee.ToString("C2")
            paymentSheet.Cells(totalRow, 4).Value = grandTotal.ToString("C2")
            paymentSheet.Cells(totalRow, 1).Font.Bold = True
            paymentSheet.Cells(totalRow, 2).Font.Bold = True
            paymentSheet.Cells(totalRow, 3).Font.Bold = True
            paymentSheet.Cells(totalRow, 4).Font.Bold = True
        End If

        worksheet.Activate()
        workBook.SaveAs(filePath)
        workBook.Close()
        excelApp.Quit()

        ' Clean up
        releaseObject(worksheet)
        releaseObject(workBook)
        releaseObject(excelApp)
    End Sub

    ' Helper method to release Excel COM objects
    Private Sub releaseObject(ByVal obj As Object)
        Try
            Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub ReportSA_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtreportn_TextChanged(sender As Object, e As EventArgs) Handles txtreportn.TextChanged

    End Sub

    Private Sub cmbreport_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
End Class